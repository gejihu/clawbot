// src/types.ts - 补充导出 MessageContext

export interface FeishuConfig {
  appId: string;
  appSecret: string;
  encryptKey?: string;
  verificationToken?: string;
  allowFrom?: string[];
  replyDelayMode?: 'non-mention' | 'always';
  replyDelayMs?: number;
}

export interface MessageContext {
  messageId: string;
  chatId: string;
  chatType: string;
  senderId: string;
  senderType: string;
  content: string;
  isMentioned: boolean;
  mentions?: Array<{
    key: string;
    id: {
      union_id?: string;
      user_id?: string;
      open_id: string;
    };
    name: string;
    tenant_key: string;
  }>;
}

export interface FeishuTokenResponse {
  code: number;
  msg: string;
  tenant_access_token?: string;
  expire?: number;
}

export interface FeishuWebSocketResponse {
  code: number;
  msg: string;
  data?: {
    url?: string;
  };
}

export interface FeishuMessageEvent {
  header: {
    event_id: string;
    event_type: string;
    create_time: string;
    token: string;
    app_id: string;
    tenant_key: string;
  };
  event: {
    sender: {
      sender_id: {
        union_id?: string;
        user_id?: string;
        open_id: string;
      };
      sender_type: string;
      tenant_key: string;
    };
    message: {
      message_id: string;
      root_id?: string;
      parent_id?: string;
      create_time: string;
      chat_id: string;
      chat_type: string;
      message_type: string;
      content: string;
      mentions?: Array<{
        key: string;
        id: {
          union_id?: string;
          user_id?: string;
          open_id: string;
        };
        name: string;
        tenant_key: string;
      }>;
    };
  };
}

export interface FeishuResponseMessage {
  msg_type: 'text' | 'post' | 'image' | 'interactive' | 'share_chat' | 'file';
  content: string;
}

export interface FeishuUserInfo {
  union_id?: string;
  user_id?: string;
  open_id: string;
  name?: string;
  en_name?: string;
}
