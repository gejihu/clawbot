// src/message-handler.ts

import { FeishuMessageEvent, FeishuConfig } from './types.js';

export interface MessageContext {
  messageId: string;
  chatId: string;
  chatType: string;
  senderId: string;
  senderType: string;
  content: string;
  isMentioned: boolean;
  mentions?: Array<{
    key: string;
    id: {
      union_id?: string;
      user_id?: string;
      open_id: string;
    };
    name: string;
    tenant_key: string;
  }>;
}

export class MessageHandler {
  private config: FeishuConfig;

  constructor(config: FeishuConfig) {
    this.config = config;
  }

  parseMessage(event: FeishuMessageEvent): MessageContext | null {
    try {
      const { message, sender } = event.event;
      
      // 解析消息内容
      let content: string;
      try {
        const parsedContent = JSON.parse(message.content);
        content = parsedContent.text || '';
      } catch {
        content = message.content;
      }

      // 判断是否是 @ 提及
      const isMentioned = this.checkIsMentioned(message.mentions);

      return {
        messageId: message.message_id,
        chatId: message.chat_id,
        chatType: message.chat_type,
        senderId: sender.sender_id.open_id,
        senderType: sender.sender_type,
        content: this.cleanContent(content),
        isMentioned,
        mentions: message.mentions,
      };
    } catch (error) {
      console.error('[Feishu] Error parsing message:', error);
      return null;
    }
  }

  private checkIsMentioned(mentions?: Array<any>): boolean {
    if (!mentions || mentions.length === 0) {
      return false;
    }
    // 检查是否有 @机器人的提及
    return mentions.some(mention => mention.id.open_id !== undefined);
  }

  private cleanContent(content: string): string {
    // 移除 @提及的标记
    return content.replace(/@\S+/g, '').trim();
  }

  shouldProcessMessage(context: MessageContext): boolean {
    // 检查白名单
    if (!this.isAuthorizedUser(context.senderId)) {
      console.log(`[Feishu] User ${context.senderId} not authorized`);
      return false;
    }

    // 群聊中必须被 @ 才回复（除非配置为总是回复）
    if (context.chatType === 'group') {
      const replyMode = this.config.replyDelayMode || 'non-mention';
      if (replyMode === 'non-mention' && !context.isMentioned) {
        console.log('[Feishu] Ignoring group message without mention');
        return false;
      }
    }

    return true;
  }

  private isAuthorizedUser(userId: string): boolean {
    if (!this.config.allowFrom || this.config.allowFrom.length === 0) {
      return true;
    }
    return this.config.allowFrom.includes(userId);
  }

  formatResponse(response: string): string {
    // 格式化响应，处理 Markdown 等
    return response.trim();
  }

  async applyDelay(): Promise<void> {
    const delayMs = this.config.replyDelayMs || 0;
    if (delayMs > 0) {
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }
}
