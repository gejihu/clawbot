// src/gateway.ts

import { FeishuClient } from './feishu-client.js';
import { MessageHandler, MessageContext } from './message-handler.js';
import { FeishuConfig, FeishuMessageEvent } from './types.js';

export interface GatewayConfig {
  feishu: FeishuConfig;
  onMessage: (context: MessageContext) => Promise<string>;
}

export class FeishuGateway {
  private client: FeishuClient;
  private messageHandler: MessageHandler;
  private onMessage: (context: MessageContext) => Promise<string>;
  private isRunning: boolean = false;

  constructor(config: GatewayConfig) {
    this.client = new FeishuClient(config.feishu);
    this.messageHandler = new MessageHandler(config.feishu);
    this.onMessage = config.onMessage;
  }

  async start(): Promise<void> {
    if (this.isRunning) {
      console.log('[Feishu Gateway] Already running');
      return;
    }

    console.log('[Feishu Gateway] Starting...');

    // 注册消息处理器
    this.client.onMessage(async (event: FeishuMessageEvent) => {
      await this.handleFeishuMessage(event);
    });

    // 启动客户端
    await this.client.start();
    this.isRunning = true;

    console.log('[Feishu Gateway] Started successfully');
  }

  stop(): void {
    console.log('[Feishu Gateway] Stopping...');
    this.isRunning = false;
    this.client.stop();
  }

  private async handleFeishuMessage(event: FeishuMessageEvent): Promise<void> {
    try {
      // 解析消息
      const context = this.messageHandler.parseMessage(event);
      if (!context) {
        console.error('[Feishu Gateway] Failed to parse message');
        return;
      }

      console.log(`[Feishu Gateway] Received message from ${context.senderId}: ${context.content}`);

      // 检查是否应该处理这条消息
      if (!this.messageHandler.shouldProcessMessage(context)) {
        return;
      }

      // 应用延迟（如果需要）
      await this.messageHandler.applyDelay();

      // 处理消息并获取响应
      const response = await this.onMessage(context);

      if (response) {
        // 发送回复
        const formattedResponse = this.messageHandler.formatResponse(response);
        
        // 群聊中使用回复消息，私聊中直接发送
        if (context.chatType === 'group') {
          await this.client.replyToMessage(context.messageId, formattedResponse);
        } else {
          await this.client.sendMessage(context.chatId, formattedResponse);
        }
      }
    } catch (error) {
      console.error('[Feishu Gateway] Error handling message:', error);
    }
  }

  isRunning(): boolean {
    return this.isRunning;
  }
}
