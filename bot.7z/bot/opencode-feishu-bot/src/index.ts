// src/index.ts

import type { PluginContext, PluginHooks, ToolContext } from '@opencode-ai/plugin';
import { FeishuGateway, GatewayConfig } from './gateway.js';
import { FeishuClient } from './feishu-client.js';
import { FeishuConfig, FeishuMessageEvent, MessageContext } from './types.js';

// 全局实例
let gateway: FeishuGateway | null = null;
let feishuClient: FeishuClient | null = null;

/**
 * 创建消息处理器，使用 OpenCode agent 处理消息
 */
function createMessageHandler(
  context: PluginContext,
  config: FeishuConfig
): GatewayConfig['onMessage'] {
  return async (messageContext: MessageContext): Promise<string> => {
    console.log(`[Feishu Bot] Processing message from ${messageContext.senderId}: ${messageContext.content}`);
    
    try {
      // 构建系统提示词
      const systemPrompt = `You are a helpful AI assistant responding to a message from Feishu/Lark (飞书).

User Information:
- User ID: ${messageContext.senderId}
- Chat Type: ${messageContext.chatType}
- Is Mentioned: ${messageContext.isMentioned}

Instructions:
1. Be concise and helpful in your response
2. Respond in the same language as the user's message
3. If you're unsure about something, say so
4. For code-related questions, provide clear, working examples

Context: This is a conversation through Feishu bot interface.`;

      // 使用 OpenCode client 与 AI 对话
      // 注意：实际的 API 可能因 OpenCode 版本而异
      let response: string;
      
      if (context.client) {
        // 方式 1: 使用 OpenCode SDK client (如果可用)
        try {
          // 尝试调用 OpenCode 的对话功能
          // 这里假设 client 有某种方式可以进行对话
          // 实际的 API 调用可能需要根据 OpenCode 文档调整
          const result = await context.client.chat.completions?.create?.({
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user', content: messageContext.content }
            ],
            model: 'default'
          });
          
          response = result?.choices?.[0]?.message?.content || 
            'Sorry, I could not generate a response.';
        } catch (clientError) {
          console.log('[Feishu Bot] Client chat failed, falling back to local processing');
          // 如果 client 调用失败，使用备用逻辑
          response = await fallbackProcessMessage(messageContext, systemPrompt);
        }
      } else {
        // 方式 2: 备用处理逻辑
        response = await fallbackProcessMessage(messageContext, systemPrompt);
      }

      return response || 'Sorry, I could not process your request.';
    } catch (error) {
      console.error('[Feishu Bot] Error processing message:', error);
      return 'Sorry, an error occurred while processing your message. Please try again later.';
    }
  };
}

/**
 * 备用消息处理逻辑（当无法调用 OpenCode API 时使用）
 */
async function fallbackProcessMessage(
  messageContext: MessageContext,
  systemPrompt: string
): Promise<string> {
  // 这里可以实现简单的规则匹配或调用其他 AI 服务
  const content = messageContext.content.toLowerCase();
  
  // 简单的关键词回复
  if (content.includes('hello') || content.includes('你好') || content.includes('hi')) {
    return '你好！我是 OpenCode AI 助手。有什么可以帮助你的吗？';
  }
  
  if (content.includes('help') || content.includes('帮助')) {
    return `我可以帮助你：
• 回答技术问题
• 编写和审查代码
• 解释复杂概念

注意：目前插件尚未完全集成 OpenCode 对话系统。完整的 AI 对话功能需要正确配置 OpenCode API。`;
  }
  
  if (content.includes('time') || content.includes('时间')) {
    return `当前时间: ${new Date().toLocaleString('zh-CN')}`;
  }
  
  // 默认回复
  return `我收到了你的消息："${messageContext.content}"\n\n⚠️ 注意：插件需要正确配置 OpenCode API 才能调用 AI 对话功能。\n\n请确保：\n1. OpenCode 已正确安装和配置\n2. 插件有权限访问 OpenCode 的 agent 功能\n3. 网络连接正常`;
}

/**
 * OpenCode Feishu Bot Plugin
 * 
 * 这个插件让 OpenCode 具备与飞书机器人对话的能力
 */
export default function feishuBotPlugin(context: PluginContext): PluginHooks {
  // 获取配置
  const config = context.config?.feishu as FeishuConfig | undefined;

  if (!config) {
    console.warn('[Feishu Bot] No configuration found. Please add feishu config to opencode.json');
    return {};
  }

  if (!config.appId || !config.appSecret) {
    console.warn('[Feishu Bot] Missing appId or appSecret in configuration');
    return {};
  }

  // 创建 Feishu 客户端实例（用于工具调用）
  if (!feishuClient) {
    feishuClient = new FeishuClient(config);
  }

  return {
    // 工具钩子 - 添加飞书相关的工具
    tool: {
      'feishu_send_message': {
        description: 'Send a message to a Feishu/Lark chat. Use this to send notifications or replies to Feishu users or groups.',
        parameters: {
          type: 'object',
          properties: {
            chatId: {
              type: 'string',
              description: 'The chat ID to send the message to (usually starts with "oc_" for groups or "ou_" for users)',
            },
            content: {
              type: 'string',
              description: 'The message content to send',
            },
            messageType: {
              type: 'string',
              enum: ['text', 'post'],
              description: 'The type of message: text for plain text, post for rich text',
              default: 'text',
            },
          },
          required: ['chatId', 'content'],
        },
        async execute(
          params: { chatId: string; content: string; messageType?: string },
          toolContext: ToolContext
        ) {
          try {
            const success = await feishuClient!.sendMessage(
              params.chatId,
              params.content,
              params.messageType || 'text'
            );
            
            if (success) {
              return {
                success: true,
                message: `Message sent successfully to chat ${params.chatId}`,
              };
            } else {
              return {
                success: false,
                error: 'Failed to send message. Please check the chat ID and try again.',
              };
            }
          } catch (error) {
            console.error('[Feishu Bot] Error sending message:', error);
            return {
              success: false,
              error: `Error sending message: ${error instanceof Error ? error.message : String(error)}`,
            };
          }
        },
      },

      'feishu_reply_message': {
        description: 'Reply to a specific message in Feishu/Lark. Use this to reply to a user message.',
        parameters: {
          type: 'object',
          properties: {
            messageId: {
              type: 'string',
              description: 'The message ID to reply to',
            },
            content: {
              type: 'string',
              description: 'The reply content',
            },
          },
          required: ['messageId', 'content'],
        },
        async execute(
          params: { messageId: string; content: string },
          toolContext: ToolContext
        ) {
          try {
            const success = await feishuClient!.replyToMessage(
              params.messageId,
              params.content
            );
            
            return {
              success,
              message: success 
                ? 'Reply sent successfully' 
                : 'Failed to send reply',
            };
          } catch (error) {
            return {
              success: false,
              error: String(error),
            };
          }
        },
      },

      'feishu_gateway_status': {
        description: 'Check the status of the Feishu bot gateway connection',
        parameters: {
          type: 'object',
          properties: {},
        },
        async execute(_params: {}, toolContext: ToolContext) {
          return {
            running: gateway !== null,
            status: gateway ? 'connected' : 'disconnected',
            timestamp: new Date().toISOString(),
          };
        },
      },
    },

    // 命令钩子 - 添加自定义命令
    command: {
      'feishu-gateway': {
        description: 'Start the Feishu bot gateway to receive and respond to messages from Feishu/Lark',
        async execute() {
          if (gateway) {
            console.log('[Feishu Bot] Gateway is already running');
            return;
          }

          console.log('='.repeat(60));
          console.log('OpenCode Feishu Bot Gateway');
          console.log('='.repeat(60));
          console.log('Starting gateway...');
          console.log('Press Ctrl+C to stop\n');

          // 创建消息处理器
          const messageHandler = createMessageHandler(context, config);

          // 创建网关实例
          gateway = new FeishuGateway({
            feishu: config,
            onMessage: messageHandler,
          });

          // 启动网关
          await gateway.start();
          console.log('[Feishu Bot] Gateway started successfully!');
          console.log('[Feishu Bot] Waiting for messages from Feishu...\n');

          // 保持进程运行
          return new Promise((resolve) => {
            const cleanup = () => {
              console.log('\n[Feishu Bot] Stopping gateway...');
              gateway?.stop();
              gateway = null;
              console.log('[Feishu Bot] Gateway stopped');
              resolve(undefined);
            };

            process.on('SIGINT', cleanup);
            process.on('SIGTERM', cleanup);
          });
        },
      },

      'feishu-status': {
        description: 'Check the Feishu bot connection and configuration status',
        async execute() {
          console.log('='.repeat(60));
          console.log('Feishu Bot Status');
          console.log('='.repeat(60));
          
          if (gateway) {
            console.log('✅ Gateway: Running');
          } else {
            console.log('❌ Gateway: Not running');
            console.log('   Start with: opencode feishu-gateway');
          }
          
          console.log('\nConfiguration:');
          console.log(`  App ID: ${config.appId.substring(0, 8)}...`);
          console.log(`  App Secret: ${'*'.repeat(10)}`);
          console.log(`  Allow From: ${config.allowFrom?.length ? config.allowFrom.join(', ') : 'All users'}`);
          console.log(`  Reply Mode: ${config.replyDelayMode || 'non-mention'}`);
          console.log(`  Reply Delay: ${config.replyDelayMs || 0}ms`);
          
          console.log('\nOpenCode Integration:');
          console.log(`  Client Available: ${context.client ? 'Yes' : 'No'}`);
          console.log(`  Project ID: ${context.project?.id || 'N/A'}`);
          console.log(`  Worktree: ${context.project?.worktree || 'N/A'}`);
          console.log('='.repeat(60));
        },
      },

      'feishu-test': {
        description: 'Test the Feishu bot connection by sending a test message',
        async execute(args: string[]) {
          const chatId = args[0];
          
          if (!chatId) {
            console.log('Usage: opencode feishu-test <chat-id>');
            console.log('Example: opencode feishu-test oc_1234567890abcdef');
            return;
          }

          console.log(`[Feishu Bot] Sending test message to ${chatId}...`);
          
          try {
            const success = await feishuClient!.sendMessage(
              chatId,
              '🤖 Hello from OpenCode Feishu Bot!\n\nThis is a test message.\n\nIf you see this, the bot is working correctly! ✅',
              'text'
            );
            
            if (success) {
              console.log('✅ Test message sent successfully!');
            } else {
              console.log('❌ Failed to send test message');
            }
          } catch (error) {
            console.error('❌ Error:', error);
          }
        },
      },
    },

    // 事件钩子 - 监听系统事件
    events: {
      // 当消息被创建时
      'message.created': async (event: any) => {
        // 可以在这里处理 OpenCode 内部的消息事件
        // 如果需要与飞书双向同步，可以在这里实现
        console.log('[Feishu Bot] OpenCode message created:', event?.message?.content?.substring(0, 50));
      },
    },

    // 初始化钩子
    async onInit() {
      console.log('[Feishu Bot] Plugin initialized successfully');
      console.log('[Feishu Bot] Available commands:');
      console.log('  - opencode feishu-gateway  : Start the gateway');
      console.log('  - opencode feishu-status   : Check status');
      console.log('  - opencode feishu-test     : Send test message');
      console.log('[Feishu Bot] Available tools:');
      console.log('  - feishu_send_message      : Send message to Feishu');
      console.log('  - feishu_reply_message     : Reply to a message');
      console.log('  - feishu_gateway_status    : Check gateway status');
    },

    // 清理钩子
    async onCleanup() {
      if (gateway) {
        console.log('[Feishu Bot] Cleaning up gateway...');
        gateway.stop();
        gateway = null;
      }
      feishuClient = null;
    },
  };
}

// 导出类型供用户使用
export * from './types.js';
export { FeishuClient } from './feishu-client.js';
export { FeishuGateway } from './gateway.js';
export { MessageHandler } from './message-handler.js';
