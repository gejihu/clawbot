// src/feishu-client.ts

import WebSocket from 'ws';
import { FeishuConfig, FeishuTokenResponse, FeishuWebSocketResponse, FeishuMessageEvent } from './types.js';

export class FeishuClient {
  private config: FeishuConfig;
  private ws: WebSocket | null = null;
  private token: string | null = null;
  private tokenExpireTime: number = 0;
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 5;
  private reconnectDelay: number = 5000;
  private messageHandlers: Array<(event: FeishuMessageEvent) => void> = [];
  private isRunning: boolean = false;

  constructor(config: FeishuConfig) {
    this.config = config;
  }

  async start(): Promise<void> {
    if (this.isRunning) {
      console.log('[Feishu] Client already running');
      return;
    }

    this.isRunning = true;
    await this.connect();
  }

  stop(): void {
    this.isRunning = false;
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  onMessage(handler: (event: FeishuMessageEvent) => void): void {
    this.messageHandlers.push(handler);
  }

  private async connect(): Promise<void> {
    try {
      // 获取 tenant access token
      await this.refreshToken();

      // 获取 WebSocket URL
      const wsUrl = await this.getWebSocketUrl();
      
      if (!wsUrl) {
        throw new Error('Failed to get WebSocket URL');
      }

      // 建立 WebSocket 连接
      this.ws = new WebSocket(wsUrl);

      this.ws.on('open', () => {
        console.log('[Feishu] WebSocket connected');
        this.reconnectAttempts = 0;
      });

      this.ws.on('message', (data: WebSocket.Data) => {
        this.handleMessage(data.toString());
      });

      this.ws.on('close', () => {
        console.log('[Feishu] WebSocket disconnected');
        this.attemptReconnect();
      });

      this.ws.on('error', (error) => {
        console.error('[Feishu] WebSocket error:', error);
      });

    } catch (error) {
      console.error('[Feishu] Connection error:', error);
      this.attemptReconnect();
    }
  }

  private async refreshToken(): Promise<void> {
    // 检查 token 是否仍有效
    if (this.token && Date.now() < this.tokenExpireTime) {
      return;
    }

    try {
      const response = await fetch('https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          app_id: this.config.appId,
          app_secret: this.config.appSecret,
        }),
      });

      const data: FeishuTokenResponse = await response.json();

      if (data.code === 0 && data.tenant_access_token) {
        this.token = data.tenant_access_token;
        this.tokenExpireTime = Date.now() + (data.expire || 7200) * 1000 - 60000; // 提前1分钟过期
        console.log('[Feishu] Token refreshed');
      } else {
        throw new Error(`Failed to get token: ${data.msg}`);
      }
    } catch (error) {
      console.error('[Feishu] Token refresh error:', error);
      throw error;
    }
  }

  private async getWebSocketUrl(): Promise<string | null> {
    try {
      await this.refreshToken();

      const response = await fetch('https://open.feishu.cn/open-apis/event/v1/endpoints', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.token}`,
        },
      });

      const data: FeishuWebSocketResponse = await response.json();

      if (data.code === 0 && data.data?.url) {
        return data.data.url;
      } else {
        console.error('[Feishu] Failed to get WebSocket URL:', data.msg);
        return null;
      }
    } catch (error) {
      console.error('[Feishu] Get WebSocket URL error:', error);
      return null;
    }
  }

  private handleMessage(data: string): void {
    try {
      const event = JSON.parse(data);
      
      // 处理心跳
      if (event.type === 'ping') {
        this.ws?.send(JSON.stringify({ type: 'pong' }));
        return;
      }

      // 处理消息事件
      if (event.schema === '2.0' && event.header?.event_type === 'im.message.receive_v1') {
        console.log('[Feishu] Received message event');
        this.messageHandlers.forEach(handler => handler(event as FeishuMessageEvent));
      }
    } catch (error) {
      console.error('[Feishu] Message handling error:', error);
    }
  }

  private attemptReconnect(): void {
    if (!this.isRunning) return;

    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('[Feishu] Max reconnect attempts reached');
      return;
    }

    this.reconnectAttempts++;
    console.log(`[Feishu] Reconnecting... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);

    setTimeout(() => {
      this.connect();
    }, this.reconnectDelay);
  }

  async sendMessage(chatId: string, content: string, msgType: string = 'text'): Promise<boolean> {
    try {
      await this.refreshToken();

      let messageBody: any;
      
      if (msgType === 'text') {
        messageBody = {
          msg_type: 'text',
          content: JSON.stringify({ text: content }),
        };
      } else if (msgType === 'post') {
        messageBody = {
          msg_type: 'post',
          content: JSON.stringify({
            post: {
              zh_cn: {
                title: '',
                content: [[{ tag: 'text', text: content }]],
              },
            },
          }),
        };
      } else {
        messageBody = {
          msg_type: 'text',
          content: JSON.stringify({ text: content }),
        };
      }

      const response = await fetch(`https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          receive_id: chatId,
          ...messageBody,
        }),
      });

      const data = await response.json();

      if (data.code === 0) {
        console.log('[Feishu] Message sent successfully');
        return true;
      } else {
        console.error('[Feishu] Failed to send message:', data.msg);
        return false;
      }
    } catch (error) {
      console.error('[Feishu] Send message error:', error);
      return false;
    }
  }

  async replyToMessage(messageId: string, content: string, msgType: string = 'text'): Promise<boolean> {
    try {
      await this.refreshToken();

      let messageBody: any;
      
      if (msgType === 'text') {
        messageBody = {
          msg_type: 'text',
          content: JSON.stringify({ text: content }),
        };
      } else {
        messageBody = {
          msg_type: 'text',
          content: JSON.stringify({ text: content }),
        };
      }

      const response = await fetch(`https://open.feishu.cn/open-apis/im/v1/messages/${messageId}/reply`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(messageBody),
      });

      const data = await response.json();

      if (data.code === 0) {
        console.log('[Feishu] Reply sent successfully');
        return true;
      } else {
        console.error('[Feishu] Failed to send reply:', data.msg);
        return false;
      }
    } catch (error) {
      console.error('[Feishu] Send reply error:', error);
      return false;
    }
  }

  isAuthorizedUser(userId: string): boolean {
    if (!this.config.allowFrom || this.config.allowFrom.length === 0) {
      return true; // 未配置白名单时允许所有用户
    }
    return this.config.allowFrom.includes(userId);
  }
}
