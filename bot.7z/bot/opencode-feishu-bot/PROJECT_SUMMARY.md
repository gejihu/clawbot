# OpenCode Feishu Bot 插件 - 项目总结

## 项目概述

这是一个参考 [nanobot](https://github.com/HKUDS/nanobot) 项目创建的 OpenCode 插件，让 OpenCode 具备与飞书机器人对话的能力。

## 文件结构

```
opencode-feishu-bot/
├── src/                          # 源代码
│   ├── index.ts                  # 插件主入口，定义 OpenCode 插件钩子
│   ├── feishu-client.ts          # 飞书 API 客户端（WebSocket + HTTP）
│   ├── gateway.ts                # 网关逻辑，连接客户端和消息处理器
│   ├── message-handler.ts        # 消息解析和过滤逻辑
│   └── types.ts                  # TypeScript 类型定义
│
├── examples/                     # 使用示例
│   ├── basic-usage.ts            # 基础用法示例
│   ├── with-opencode-agent.ts    # 与 OpenCode Agent 集成示例
│   ├── custom-handler.ts         # 自定义消息处理器示例
│   ├── test-opencode-integration.ts  # OpenCode 集成测试
│   └── README.md                 # 示例说明文档
│
├── package.json                  # npm 包配置
├── tsconfig.json                 # TypeScript 配置
├── README.md                     # 项目说明文档
├── GUIDE.md                      # 详细使用指南
├── INTEGRATION.md                # OpenCode 集成验证文档
├── CHANGELOG.md                  # 变更日志
├── PROJECT_SUMMARY.md            # 本文件
├── LICENSE                       # MIT 许可证
├── .gitignore                    # Git 忽略配置
└── opencode.json.example         # 配置文件示例
```

## 核心功能

### 1. FeishuClient (feishu-client.ts)

负责与飞书 API 通信：
- **Token 管理**：自动获取和刷新 tenant_access_token
- **WebSocket 连接**：建立长连接接收实时消息
- **自动重连**：断线后自动重连，最多 5 次
- **消息发送**：支持发送消息和回复消息
- **心跳检测**：保持 WebSocket 连接活跃

### 2. FeishuGateway (gateway.ts)

网关层，协调各个组件：
- 启动/停止 WebSocket 连接
- 消息事件分发
- 调用 OpenCode Agent 处理消息
- 发送回复到飞书

### 3. MessageHandler (message-handler.ts)

消息处理逻辑：
- 解析飞书消息格式
- 检查是否是 @提及
- 白名单权限验证
- 消息内容清理
- 延迟策略应用

### 4. 插件入口 (index.ts)

OpenCode 插件定义，集成 OpenCode 核心功能：

#### 工具钩子 (Tools)
- `feishu_send_message` - 发送飞书消息
- `feishu_reply_message` - 回复飞书消息
- `feishu_gateway_status` - 检查网关状态

#### 命令钩子 (Commands)
- `feishu-gateway` - 启动飞书网关
- `feishu-status` - 查看状态
- `feishu-test` - 发送测试消息

#### 生命周期钩子
- `onInit` - 初始化
- `onCleanup` - 清理
- `events` - 事件监听

## OpenCode 集成详解

### 集成架构

```
┌─────────────────────────────────────────────────────┐
│              OpenCode Core                          │
│  ┌──────────┐ ┌──────────┐ ┌──────────────────┐   │
│  │  Agent   │ │  Tools   │ │    Commands      │   │
│  │(AI对话)  │ │(工具系统)│ │   (CLI命令)      │   │
│  └────┬─────┘ └────┬─────┘ └────────┬─────────┘   │
│       └─────────────┴────────────────┘             │
│                     │                              │
│              Plugin Context                        │
│                     │                              │
└─────────────────────┼──────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────┐
│         opencode-feishu-bot Plugin                  │
│  ┌──────────┐ ┌──────────┐ ┌──────────────────┐   │
│  │  Gateway │ │  Tools   │ │    Commands      │   │
│  │ (消息网关)│ │(飞书工具)│ │  (网关命令)      │   │
│  └────┬─────┘ └────┬─────┘ └────────┬─────────┘   │
│       └─────────────┴────────────────┘             │
│                     │                              │
└─────────────────────┼──────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────┐
│              Feishu/Lark API                        │
│           (WebSocket + HTTP)                        │
└─────────────────────────────────────────────────────┘
```

### 集成点

#### 1. 调用 OpenCode AI Agent

当收到飞书消息时，插件尝试调用 OpenCode AI：

```typescript
// src/index.ts - createMessageHandler()
if (context.client) {
  const result = await context.client.chat.completions.create({
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: messageContext.content }
    ]
  });
  response = result.choices[0].message.content;
} else {
  // 自动降级到备用逻辑
  response = await fallbackProcessMessage(...);
}
```

**数据流向**:
```
飞书用户 → WebSocket → 插件 → context.client → OpenCode Agent → 回复 → 飞书
```

#### 2. 注册 OpenCode 工具

插件向 OpenCode 工具系统注册飞书相关工具：

```typescript
tool: {
  'feishu_send_message': {
    description: 'Send a message to Feishu...',
    parameters: { ... },
    execute: async (params, toolContext) => {
      return await feishuClient.sendMessage(...);
    }
  }
}
```

**使用场景**:
- 用户在 OpenCode 中说："发送飞书消息给张三说项目完成了"
- OpenCode AI 识别意图，调用 `feishu_send_message`
- 插件执行发送操作

#### 3. 注册 OpenCode 命令

插件扩展 OpenCode CLI：

```typescript
command: {
  'feishu-gateway': {
    description: 'Start Feishu bot gateway',
    async execute() {
      // 启动 WebSocket 连接
      // 开始监听飞书消息
    }
  }
}
```

#### 4. 监听 OpenCode 事件

```typescript
events: {
  'message.created': async (event) => {
    // 监听 OpenCode 内部消息
    // 可实现双向同步
  }
}
```

## 使用方法

### 方法 1：作为 OpenCode 插件使用

1. **安装插件**：
```bash
npm install opencode-feishu-bot
```

2. **配置** `opencode.json`：
```json
{
  "plugins": ["opencode-feishu-bot"],
  "feishu": {
    "appId": "cli_xxxxxxxx",
    "appSecret": "xxxxxxxx",
    "allowFrom": []
  }
}
```

3. **启动网关**：
```bash
opencode feishu-gateway
```

### 方法 2：程序化使用

```typescript
import { FeishuGateway } from 'opencode-feishu-bot';

const gateway = new FeishuGateway({
  feishu: {
    appId: 'cli_xxx',
    appSecret: 'xxx',
  },
  onMessage: async (context) => {
    return `收到: ${context.content}`;
  },
});

await gateway.start();
```

## 飞书应用配置步骤

1. **创建应用**：https://open.feishu.cn/app
2. **添加机器人能力**：应用管理 → 添加应用能力 → 机器人
3. **配置权限**：
   - `im:message:send_as_bot`
   - `im:message.group_msg`
   - `im:message.p2p_msg`
4. **配置事件订阅**：
   - 启用"长连接"模式
   - 添加事件：`im.message.receive_v1`
5. **获取凭证**：
   - App ID
   - App Secret
6. **发布应用**：版本管理与发布 → 创建版本 → 申请发布

## 集成验证

### 测试 1: 验证工具注册

```bash
# 在 OpenCode 中输入
"显示所有可用工具"
# 应该看到 feishu_send_message, feishu_reply_message 等
```

### 测试 2: 验证命令

```bash
opencode feishu-status
opencode feishu-gateway
```

### 测试 3: 验证 AI 对话集成

```bash
# 1. 启动网关
opencode feishu-gateway

# 2. 在飞书中发送消息
# 3. 观察控制台，确认是否调用 OpenCode API
```

### 测试 4: 工具调用

在 OpenCode 对话中：
```
用户: "发送飞书消息到 oc_1234 说测试消息"
AI: 调用 feishu_send_message 工具
    参数: { chatId: 'oc_1234', content: '测试消息' }
```

## 特性对比

| 特性 | 本插件 | nanobot |
|------|--------|---------|
| 定位 | OpenCode 插件 | Python CLI 工具 |
| 代码量 | ~800 行 | ~4000 行 |
| 飞书支持 | ✅ | ✅ |
| 其他平台 | ❌ (专注飞书) | ✅ (多平台) |
| WebSocket | ✅ | ✅ |
| 自动重连 | ✅ | ✅ |
| 白名单 | ✅ | ✅ |
| 延迟回复 | ✅ | ✅ |
| **OpenCode 集成** | **✅ (深度)** | ❌ (独立) |
| **工具系统** | **✅ (OpenCode)** | ❌ (自建) |
| **命令系统** | **✅ (OpenCode)** | ❌ (自建) |

## 扩展建议

如需支持其他平台（钉钉、企业微信等），可参考本插件结构：

1. 创建平台客户端类（类似 `FeishuClient`）
2. 实现平台特定的消息格式解析
3. 创建网关类统一接口
4. 注册为 OpenCode 插件

## 技术亮点

1. **TypeScript 全程类型安全**
2. **模块化解耦**：客户端、网关、处理器分离
3. **错误处理完善**：包含重连、降级策略
4. **符合 OpenCode 插件规范**
5. **完整的文档和示例**
6. **深度 OpenCode 集成**：工具、命令、事件、Agent

## 故障排除

### 问题: 无法调用 OpenCode Agent

**症状**: 飞书消息能收到，但回复是备用逻辑的内容

**检查**:
1. 查看控制台输出 `Client Available: Yes/No`
2. 检查 OpenCode 版本兼容性
3. 确认 OpenCode 已配置 AI Provider

**解决**:
- 当前实现包含自动降级，即使 OpenCode API 不可用也能工作
- 可根据实际 OpenCode 版本调整 `context.client` 调用方式

### 问题: 工具未显示

**检查**:
```bash
opencode --verbose
# 查看插件加载日志
```

## 下一步

1. 发布到 npm：`npm publish`
2. 根据实际 OpenCode 版本调整 API 调用
3. 添加更多消息类型支持（图片、卡片等）
4. 添加消息历史记录功能
5. 支持更多 IM 平台

## 参考文档

- [INTEGRATION.md](./INTEGRATION.md) - 详细的集成验证文档
- [GUIDE.md](./GUIDE.md) - 详细使用指南
- [examples/README.md](./examples/README.md) - 示例说明

## 许可证

MIT License - 可自由使用和修改
