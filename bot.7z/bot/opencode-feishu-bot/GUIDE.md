# OpenCode Feishu Bot 插件使用指南

## 快速开始

### 1. 安装插件

```bash
npm install opencode-feishu-bot
```

### 2. 创建飞书应用

1. 访问 [飞书开放平台](https://open.feishu.cn/app)
2. 点击"创建企业自建应用"
3. 填写应用名称和描述
4. 进入应用管理页面

### 3. 配置机器人能力

1. 在应用管理页面，点击"添加应用能力"
2. 选择"机器人"并添加
3. 配置机器人信息（名称、头像等）

### 4. 配置权限

1. 进入"权限管理"
2. 添加以下权限：
   - `im:message:send_as_bot` - 以机器人身份发送消息
   - `im:message.group_msg` - 接收群聊消息
   - `im:message.p2p_msg` - 接收单聊消息

### 5. 配置事件订阅

1. 进入"事件订阅"
2. 打开"长连接"模式
3. 添加以下事件：
   - `im.message.receive_v1` - 接收消息事件

### 6. 获取凭证

1. 进入"凭证与基础信息"
2. 复制 **App ID** 和 **App Secret**

### 7. 配置 OpenCode

在你的项目目录创建或编辑 `opencode.json`：

```json
{
  "$schema": "https://opencode.ai/config.json",
  "plugins": ["opencode-feishu-bot"],
  "feishu": {
    "appId": "cli_xxxxxxxxxxxxxxxx",
    "appSecret": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    "encryptKey": "",
    "verificationToken": "",
    "allowFrom": [],
    "replyDelayMode": "non-mention",
    "replyDelayMs": 0
  }
}
```

### 8. 发布应用

1. 进入"版本管理与发布"
2. 点击"创建版本"
3. 填写版本信息
4. 点击"申请发布"

### 9. 启动网关

```bash
opencode feishu-gateway
```

## 使用方式

### 私聊

直接在飞书中搜索你的机器人名称，点击"发消息"即可开始对话。

### 群聊

将机器人添加到群聊后，@机器人即可触发对话：

```
@机器人 你好，请帮我写一个 Python 函数
```

## 配置说明

### allowFrom - 用户白名单

限制只有特定用户可以访问机器人：

```json
{
  "feishu": {
    "allowFrom": ["ou_xxxxxxxxxxxxxxxx", "ou_yyyyyyyyyyyyyyyy"]
  }
}
```

获取用户 ID 的方法：
1. 先不配置白名单，让所有人都能访问
2. 用户发送消息后，查看 OpenCode 日志中的 `senderId`
3. 将用户 ID 添加到白名单

### replyDelayMode - 回复模式

- `"non-mention"` (默认): 群聊中必须 @机器人才会回复
- `"always"`: 群聊中所有消息都会回复

### replyDelayMs - 回复延迟

设置回复延迟时间（毫秒），避免回复过快：

```json
{
  "feishu": {
    "replyDelayMs": 1000
  }
}
```

## 高级功能

### 自定义消息处理

你可以通过代码方式自定义消息处理逻辑：

```typescript
import { FeishuGateway, MessageContext } from 'opencode-feishu-bot';

const gateway = new FeishuGateway({
  feishu: {
    appId: 'your-app-id',
    appSecret: 'your-app-secret',
  },
  onMessage: async (context: MessageContext) => {
    // 自定义处理逻辑
    console.log(`收到消息: ${context.content}`);
    
    // 返回回复内容
    return `收到你的消息: ${context.content}`;
  },
});

await gateway.start();
```

### 发送主动消息

```typescript
import { FeishuClient } from 'opencode-feishu-bot';

const client = new FeishuClient({
  appId: 'your-app-id',
  appSecret: 'your-app-secret',
});

await client.sendMessage('chat_id', '这是主动发送的消息');
```

## 故障排除

### 无法连接

1. 检查 App ID 和 App Secret 是否正确
2. 确认应用已发布
3. 检查网络连接

### 收不到消息

1. 确认已添加 `im.message.receive_v1` 事件订阅
2. 确认使用的是"长连接"模式
3. 检查机器人是否已添加到群聊

### 无法回复

1. 检查是否已添加 `im:message:send_as_bot` 权限
2. 确认用户不在黑名单中
3. 检查白名单配置

## 命令参考

| 命令 | 说明 |
|------|------|
| `opencode feishu-gateway` | 启动飞书网关 |
| `opencode feishu-status` | 查看连接状态 |

## 参考链接

- [飞书开放平台文档](https://open.feishu.cn/document/ukTMukTMukTM/uITNz4iM1MjLyUzM)
- [OpenCode 插件文档](https://opencode.ai/docs/plugins)
