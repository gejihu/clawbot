# OpenCode 集成验证文档

本文档说明 `opencode-feishu-bot` 插件如何与 OpenCode 原有的指令、对话系统和工具集成。

## 集成架构

```
┌─────────────────────────────────────────────────────────────────┐
│                      OpenCode Core                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │   Agent      │  │    Tools     │  │    Commands          │  │
│  │  (AI 对话)    │  │ (内置工具)    │  │   (CLI 命令)         │  │
│  └──────┬───────┘  └──────┬───────┘  └──────────┬───────────┘  │
│         │                 │                     │              │
│         └─────────────────┴─────────────────────┘              │
│                           │                                    │
│                    Plugin Context                              │
│                           │                                    │
└───────────────────────────┼────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│              opencode-feishu-bot Plugin                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │   Gateway    │  │ Feishu Tools │  │  Custom Commands     │  │
│  │  (消息网关)   │  │(发送/回复消息)│  │ (feishu-gateway)     │  │
│  └──────┬───────┘  └──────┬───────┘  └──────────┬───────────┘  │
│         │                 │                     │              │
│         └─────────────────┴─────────────────────┘              │
│                           │                                    │
└───────────────────────────┼────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Feishu/Lark API                            │
│              (WebSocket + HTTP REST API)                        │
└─────────────────────────────────────────────────────────────────┘
```

## 集成点说明

### 1. 调用 OpenCode Agent（AI 对话）

**实现位置**: `src/index.ts` → `createMessageHandler()`

当飞书用户发送消息时，插件会尝试调用 OpenCode 的 AI 对话功能：

```typescript
// 方式 1: 使用 OpenCode SDK Client (如果可用)
if (context.client) {
  const result = await context.client.chat.completions.create({
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: messageContext.content }
    ],
    model: 'default'
  });
  response = result.choices[0].message.content;
}

// 方式 2: 备用处理（当 Client 不可用时）
else {
  response = await fallbackProcessMessage(messageContext, systemPrompt);
}
```

**数据流向**:
1. 飞书用户发送消息
2. 插件通过 WebSocket 接收
3. 调用 `context.client.chat.completions.create()`
4. OpenCode Agent 生成回复
5. 插件将回复发送回飞书

### 2. 注册 OpenCode 工具

**实现位置**: `src/index.ts` → `PluginHooks.tool`

插件向 OpenCode 注册了 3 个工具，可以被 OpenCode 的 AI Agent 调用：

#### 工具 1: `feishu_send_message`
```typescript
{
  description: 'Send a message to a Feishu/Lark chat...',
  parameters: {
    chatId: string,      // 聊天 ID
    content: string,     // 消息内容
    messageType: 'text' | 'post'
  },
  execute: async (params, toolContext) => {
    // 调用 FeishuClient 发送消息
    const success = await feishuClient.sendMessage(...);
    return { success, message: '...' };
  }
}
```

**使用场景**:
- 用户在 OpenCode 中说："发送飞书消息给张三说项目完成了"
- OpenCode AI 识别意图，调用 `feishu_send_message` 工具
- 插件执行发送操作

#### 工具 2: `feishu_reply_message`
```typescript
{
  description: 'Reply to a specific message in Feishu/Lark',
  parameters: {
    messageId: string,   // 要回复的消息 ID
    content: string      // 回复内容
  },
  execute: async (params, toolContext) => {
    const success = await feishuClient.replyToMessage(...);
    return { success, message: '...' };
  }
}
```

#### 工具 3: `feishu_gateway_status`
```typescript
{
  description: 'Check the status of the Feishu bot gateway',
  execute: async () => {
    return {
      running: gateway !== null,
      status: gateway ? 'connected' : 'disconnected'
    };
  }
}
```

### 3. 注册 OpenCode 命令

**实现位置**: `src/index.ts` → `PluginHooks.command`

插件注册了 3 个 CLI 命令：

#### 命令 1: `feishu-gateway`
启动飞书消息网关，开始接收消息：

```bash
opencode feishu-gateway
```

**功能**:
- 建立 WebSocket 连接
- 监听飞书消息
- 调用 OpenCode Agent 处理消息
- 发送回复到飞书

#### 命令 2: `feishu-status`
检查插件和网关状态：

```bash
opencode feishu-status
```

**输出示例**:
```
============================================================
Feishu Bot Status
============================================================
❌ Gateway: Not running
   Start with: opencode feishu-gateway

Configuration:
  App ID: cli_1234...
  App Secret: **********
  Allow From: All users
  Reply Mode: non-mention
  Reply Delay: 0ms

OpenCode Integration:
  Client Available: Yes
  Project ID: my-project
  Worktree: /path/to/project
============================================================
```

#### 命令 3: `feishu-test`
发送测试消息：

```bash
opencode feishu-test oc_1234567890abcdef
```

### 4. 监听 OpenCode 事件

**实现位置**: `src/index.ts` → `PluginHooks.events`

插件可以监听 OpenCode 内部事件：

```typescript
events: {
  'message.created': async (event) => {
    // 当 OpenCode 内部创建消息时触发
    console.log('[Feishu Bot] OpenCode message created:', ...);
    
    // 可以在这里实现双向同步
    // 例如：将 OpenCode 的对话同步到飞书
  }
}
```

## 集成验证清单

### ✅ 已验证的功能

1. **Plugin Context 访问**
   - [x] 访问 `context.config` 获取配置
   - [x] 访问 `context.client` 调用 OpenCode SDK
   - [x] 访问 `context.project` 获取项目信息

2. **工具注册**
   - [x] `feishu_send_message` 工具已注册
   - [x] `feishu_reply_message` 工具已注册
   - [x] `feishu_gateway_status` 工具已注册

3. **命令注册**
   - [x] `feishu-gateway` 命令已注册
   - [x] `feishu-status` 命令已注册
   - [x] `feishu-test` 命令已注册

4. **生命周期钩子**
   - [x] `onInit` 初始化钩子
   - [x] `onCleanup` 清理钩子

### ⚠️ 需要确认的功能

1. **OpenCode API 调用方式**
   - 实际 API 可能因 OpenCode 版本而异
   - 需要根据实际情况调整 `context.client.chat.completions.create` 调用
   - 当前实现包含自动降级逻辑

2. **Tool Context 参数**
   - 工具执行时接收的 `ToolContext` 对象内容
   - 可能包含 `sessionID`, `messageID`, `agent` 等信息

## 测试方法

### 测试 1: 验证工具注册

```bash
# 1. 安装插件
npm install opencode-feishu-bot

# 2. 在 opencode.json 中配置

# 3. 启动 OpenCode 并检查工具列表
opencode

# 在 OpenCode 中输入：
# "显示所有可用工具"
```

### 测试 2: 验证命令注册

```bash
# 检查命令是否可用
opencode feishu-status
opencode feishu-gateway
```

### 测试 3: 验证 AI 对话集成

```bash
# 1. 启动网关
opencode feishu-gateway

# 2. 在飞书中发送消息给机器人
# 3. 观察控制台输出，确认是否调用了 OpenCode API
```

### 测试 4: 验证工具调用

在 OpenCode 对话中：

```
用户: "检查飞书网关状态"
AI: 调用 feishu_gateway_status 工具
    返回: { running: true/false, status: 'connected' }

用户: "发送飞书消息到 oc_1234 说测试消息"
AI: 调用 feishu_send_message 工具
    参数: { chatId: 'oc_1234', content: '测试消息' }
```

## 故障排除

### 问题 1: 工具未显示

**可能原因**:
- 插件未正确安装
- `opencode.json` 配置错误
- 插件加载失败

**解决方法**:
```bash
# 检查插件加载日志
opencode --verbose

# 确认配置文件路径
cat .opencode/config.json
```

### 问题 2: 无法调用 OpenCode Agent

**可能原因**:
- `context.client` 为 undefined
- OpenCode 版本不兼容
- API 调用方式错误

**解决方法**:
1. 检查 OpenCode 版本
2. 查看控制台错误日志
3. 使用备用处理逻辑（已内置）

### 问题 3: 工具调用失败

**可能原因**:
- FeishuClient 未初始化
- 网络连接问题
- Token 过期

**解决方法**:
1. 确保网关已启动
2. 检查网络连接
3. 查看详细错误信息

## 与 nanobot 的集成对比

| 功能 | nanobot | opencode-feishu-bot |
|------|---------|---------------------|
| AI 调用方式 | 直接调用 LLM API | 通过 OpenCode Agent |
| 工具系统 | 自建工具系统 | OpenCode 工具系统 |
| 命令系统 | Python CLI | OpenCode 命令系统 |
| 配置管理 | 独立配置文件 | OpenCode 配置系统 |
| 扩展性 | 修改源码 | 插件架构 |

## 总结

本插件通过以下方式与 OpenCode 原有功能集成：

1. **AI 对话**: 通过 `context.client` 调用 OpenCode Agent
2. **工具系统**: 注册 3 个飞书相关工具到 OpenCode
3. **命令系统**: 注册 3 个 CLI 命令
4. **事件系统**: 监听 OpenCode 内部事件

所有集成点都遵循 OpenCode 插件规范，确保与 OpenCode 生态无缝兼容。
