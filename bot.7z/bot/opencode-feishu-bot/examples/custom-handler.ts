// examples/custom-handler.ts
// 自定义消息处理器示例

import { FeishuGateway, MessageContext, MessageHandler } from '../src/index.js';

// 自定义消息处理器
class CustomMessageHandler extends MessageHandler {
  // 重写消息解析逻辑
  parseMessage(event: any): MessageContext | null {
    const context = super.parseMessage(event);
    if (!context) return null;

    // 添加自定义逻辑：记录日志
    console.log(`[CustomHandler] 解析消息: ${context.content}`);

    return context;
  }

  // 重写消息处理判断
  shouldProcessMessage(context: MessageContext): boolean {
    // 先调用父类逻辑
    if (!super.shouldProcessMessage(context)) {
      return false;
    }

    // 添加自定义逻辑：忽略包含特定关键词的消息
    const blockedKeywords = ['spam', '广告', '垃圾'];
    for (const keyword of blockedKeywords) {
      if (context.content.includes(keyword)) {
        console.log(`[CustomHandler] 忽略包含敏感词的消息: ${keyword}`);
        return false;
      }
    }

    return true;
  }
}

// 命令处理器
class CommandHandler {
  private commands: Map<string, (args: string[]) => string> = new Map();

  constructor() {
    this.registerDefaultCommands();
  }

  private registerDefaultCommands() {
    this.commands.set('help', () => {
      return `可用命令：
/help - 显示帮助
/status - 查看系统状态
/calc <表达式> - 计算器
/echo <消息> - 回声
/time - 当前时间`;
    });

    this.commands.set('status', () => {
      return `系统状态：
- 运行时间: ${process.uptime().toFixed(0)} 秒
- 内存使用: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB
- Node 版本: ${process.version}`;
    });

    this.commands.set('calc', (args) => {
      try {
        const expression = args.join(' ');
        // 注意：实际使用 eval 需要注意安全性
        const result = eval(expression);
        return `计算结果: ${result}`;
      } catch {
        return '计算错误，请检查表达式';
      }
    });

    this.commands.set('echo', (args) => {
      return args.join(' ');
    });

    this.commands.set('time', () => {
      return `当前时间: ${new Date().toLocaleString('zh-CN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      })}`;
    });
  }

  handle(message: string): string | null {
    if (!message.startsWith('/')) {
      return null; // 不是命令
    }

    const parts = message.slice(1).split(' ');
    const command = parts[0].toLowerCase();
    const args = parts.slice(1);

    const handler = this.commands.get(command);
    if (handler) {
      return handler(args);
    }

    return `未知命令: /${command}\n输入 /help 查看可用命令`;
  }
}

async function main() {
  const commandHandler = new CommandHandler();

  const gateway = new FeishuGateway({
    feishu: {
      appId: process.env.FEISHU_APP_ID || '',
      appSecret: process.env.FEISHU_APP_SECRET || '',
      allowFrom: [],
      replyDelayMode: 'non-mention',
      replyDelayMs: 500,
    },
    onMessage: async (context: MessageContext) => {
      console.log(`[${context.chatType}] ${context.senderId}: ${context.content}`);

      // 首先尝试作为命令处理
      const commandResponse = commandHandler.handle(context.content);
      if (commandResponse) {
        return commandResponse;
      }

      // 处理自然语言消息
      const lowerContent = context.content.toLowerCase();
      
      if (lowerContent.includes('你好') || lowerContent.includes('hello')) {
        return '你好！有什么可以帮助你的吗？输入 /help 查看可用命令。';
      }

      if (lowerContent.includes('谢谢') || lowerContent.includes('thanks')) {
        return '不客气！很高兴能帮到你。';
      }

      if (lowerContent.includes('再见') || lowerContent.includes('bye')) {
        return '再见！有问题随时找我。';
      }

      // 默认回复
      return `我收到了你的消息："${context.content}"\n\n输入 /help 查看可用命令，或者描述你的需求，我会尽力帮助你。`;
    },
  });

  console.log('='.repeat(60));
  console.log('OpenCode Feishu Bot - 自定义处理器示例');
  console.log('='.repeat(60));
  console.log('特性：');
  console.log('- 支持命令系统 (/help, /status, /calc, /echo, /time)');
  console.log('- 敏感词过滤');
  console.log('- 自然语言回复');
  console.log();
  console.log('按 Ctrl+C 停止服务');
  console.log();

  await gateway.start();

  const shutdown = () => {
    console.log('\n正在关闭服务...');
    gateway.stop();
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

main().catch(console.error);
