// examples/with-opencode-agent.ts
// 与 OpenCode Agent 集成的示例

import { FeishuGateway, MessageContext } from '../src/index.js';

// 模拟 OpenCode Agent 调用
async function askOpenCode(prompt: string, systemPrompt?: string): Promise<string> {
  // 在实际使用中，这里会调用 OpenCode 的 agent
  // 例如：return await opencode.agent.ask(prompt, { system: systemPrompt });
  
  // 这里只是一个示例实现
  const responses: Record<string, string> = {
    'hello': '你好！我是 OpenCode AI 助手。',
    'hi': '你好！有什么可以帮助你的吗？',
    'help': `我可以帮助你：
- 回答技术问题
- 编写和审查代码
- 解释复杂概念
- 提供建议和最佳实践

直接发送你的问题即可！`,
    'code': '我可以帮你编写代码。请告诉我你需要什么功能。',
  };

  const lowerPrompt = prompt.toLowerCase().trim();
  
  // 检查是否有预设回复
  for (const [key, value] of Object.entries(responses)) {
    if (lowerPrompt.includes(key)) {
      return value;
    }
  }

  // 默认回复
  return `我收到了你的消息："${prompt}"\n\n在实际使用中，这里会由 OpenCode 的 AI Agent 处理并生成回复。`;
}

async function main() {
  const gateway = new FeishuGateway({
    feishu: {
      appId: process.env.FEISHU_APP_ID || '',
      appSecret: process.env.FEISHU_APP_SECRET || '',
      allowFrom: [],
      replyDelayMode: 'non-mention',
      replyDelayMs: 1000, // 延迟 1 秒回复，避免过快
    },
    onMessage: async (context: MessageContext) => {
      console.log(`[${new Date().toISOString()}] 收到来自 ${context.senderId} 的消息`);
      console.log(`内容: ${context.content}`);
      console.log(`类型: ${context.chatType}${context.isMentioned ? ' (被@)' : ''}`);

      // 调用 OpenCode Agent 处理消息
      const systemPrompt = `你是一个 helpful 的 AI 助手，通过飞书机器人与用户对话。
用户 ID: ${context.senderId}
对话类型: ${context.chatType}
请用中文回复，保持友好和专业的语气。`;

      try {
        const response = await askOpenCode(context.content, systemPrompt);
        console.log(`回复: ${response.substring(0, 100)}...`);
        return response;
      } catch (error) {
        console.error('处理消息时出错:', error);
        return '抱歉，处理你的消息时出现了错误，请稍后再试。';
      }
    },
  });

  console.log('='.repeat(50));
  console.log('OpenCode Feishu Bot 已启动');
  console.log('='.repeat(50));
  console.log('按 Ctrl+C 停止服务');
  console.log();

  await gateway.start();

  // 优雅退出
  const shutdown = () => {
    console.log('\n正在关闭服务...');
    gateway.stop();
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

main().catch((error) => {
  console.error('启动失败:', error);
  process.exit(1);
});
