# 示例说明

这个目录包含使用 OpenCode Feishu Bot 插件的各种示例。

## 示例列表

### 1. basic-usage.ts - 基础用法

展示如何使用代码方式启动飞书网关，包含简单的消息处理逻辑。

**功能：**
- 接收并回复消息
- 简单的命令处理（ping, help, time）
- 回声回复

**运行：**
```bash
npx tsx examples/basic-usage.ts
```

### 2. with-opencode-agent.ts - 与 OpenCode Agent 集成

展示如何将飞书机器人与 OpenCode 的 AI Agent 集成。

**功能：**
- 模拟调用 OpenCode Agent
- 系统提示词配置
- 错误处理

**运行：**
```bash
npx tsx examples/with-opencode-agent.ts
```

### 3. custom-handler.ts - 自定义消息处理器

展示如何扩展和自定义消息处理逻辑。

**功能：**
- 命令系统（/help, /status, /calc, /echo, /time）
- 敏感词过滤
- 自然语言回复
- 自定义 MessageHandler

**运行：**
```bash
npx tsx examples/custom-handler.ts
```

### 4. test-opencode-integration.ts - OpenCode 集成测试

测试插件与 OpenCode 核心功能的集成。

**功能：**
- 验证 OpenCode API 调用
- 模拟 AI 对话
- 测试工具集成
- 验证数据流向

**运行：**
```bash
npx tsx examples/test-opencode-integration.ts
```

**输出示例：**
```
======================================================================
OpenCode Feishu Bot - 集成测试
======================================================================

✅ 模拟 OpenCode 上下文已创建
   Client available: Yes
   Chat completions available: Yes
   Project ID: test-project

----------------------------------------------------------------------
测试消息处理
----------------------------------------------------------------------

📨 测试消息: "你好"
   来自: user_001 (p2p)
✅ 回复: "你好！我是 OpenCode AI 助手。很高兴为你服务！"

📨 测试消息: "帮我写一个 Python 函数"
   来自: user_003 (p2p)
✅ 回复: "我可以帮你编写代码。请告诉我你需要什么功能。"
...
```

## 环境变量

所有示例都支持以下环境变量：

```bash
export FEISHU_APP_ID="cli_xxxxxxxxxxxxxxxx"
export FEISHU_APP_SECRET="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
```

或者创建 `.env` 文件：

```
FEISHU_APP_ID=cli_xxxxxxxxxxxxxxxx
FEISHU_APP_SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

## 前提条件

1. 已创建飞书应用并获取凭证
2. 已安装依赖：`npm install`
3. 已安装 tsx：`npm install -g tsx` 或使用 `npx tsx`

## 运行步骤

1. 克隆仓库并安装依赖：
```bash
git clone <repository-url>
cd opencode-feishu-bot
npm install
```

2. 设置环境变量或在代码中配置凭证

3. 运行示例：
```bash
npx tsx examples/basic-usage.ts
```

4. 在飞书中测试：
   - 私聊机器人
   - 或在群聊中 @机器人

## 扩展建议

你可以基于这些示例开发更复杂的功能：

- **数据库集成**：记录对话历史
- **多轮对话**：维护对话上下文
- **文件处理**：接收和发送文件
- **富文本消息**：使用卡片消息格式
- **定时任务**：定时发送消息
- **Webhook**：接收外部系统通知
