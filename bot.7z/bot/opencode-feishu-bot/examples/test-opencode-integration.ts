// examples/test-opencode-integration.ts
// 测试插件与 OpenCode 核心功能的集成

import { FeishuGateway, FeishuClient, MessageContext } from '../src/index.js';

/**
 * 模拟 OpenCode PluginContext
 */
interface MockPluginContext {
  config?: {
    feishu?: {
      appId: string;
      appSecret: string;
      allowFrom?: string[];
    };
  };
  client?: {
    chat?: {
      completions?: {
        create: (params: any) => Promise<any>;
      };
    };
  };
  project?: {
    id: string;
    worktree: string;
  };
}

/**
 * 创建模拟的 OpenCode 上下文
 */
function createMockOpenCodeContext(): MockPluginContext {
  return {
    client: {
      chat: {
        completions: {
          create: async (params: any) => {
            console.log('[Mock OpenCode] Received chat completion request:');
            console.log('  Model:', params.model);
            console.log('  Messages:', JSON.stringify(params.messages, null, 2));
            
            // 模拟 AI 响应
            const lastMessage = params.messages[params.messages.length - 1];
            const content = lastMessage.content;
            
            // 简单的模拟回复逻辑
            let response = '';
            if (content.toLowerCase().includes('hello') || content.includes('你好')) {
              response = '你好！我是 OpenCode AI 助手。很高兴为你服务！';
            } else if (content.toLowerCase().includes('code') || content.includes('代码')) {
              response = '我可以帮你编写代码。请告诉我你需要什么功能。';
            } else if (content.toLowerCase().includes('help') || content.includes('帮助')) {
              response = `我可以帮助你：
• 回答技术问题
• 编写和审查代码  
• 解释复杂概念
• 提供最佳实践建议

请直接发送你的问题！`;
            } else {
              response = `我收到了你的消息："${content}"\n\n这是一个模拟的 AI 回复。在实际环境中，这里会调用 OpenCode 的 AI 模型生成回复。`;
            }
            
            return {
              choices: [{
                message: {
                  content: response,
                  role: 'assistant'
                }
              }]
            };
          }
        }
      }
    },
    project: {
      id: 'test-project',
      worktree: '/path/to/project'
    }
  };
}

/**
 * 测试函数：检查是否能调用 OpenCode API
 */
async function testOpenCodeIntegration() {
  console.log('='.repeat(70));
  console.log('OpenCode Feishu Bot - 集成测试');
  console.log('='.repeat(70));
  
  // 创建模拟上下文
  const mockContext = createMockOpenCodeContext();
  
  console.log('\n✅ 模拟 OpenCode 上下文已创建');
  console.log(`   Client available: ${mockContext.client ? 'Yes' : 'No'}`);
  console.log(`   Chat completions available: ${mockContext.client?.chat?.completions ? 'Yes' : 'No'}`);
  console.log(`   Project ID: ${mockContext.project?.id}`);
  
  // 测试模拟消息
  const testMessages = [
    { content: '你好', senderId: 'user_001', chatType: 'p2p' },
    { content: 'help', senderId: 'user_002', chatType: 'group' },
    { content: '帮我写一个 Python 函数', senderId: 'user_003', chatType: 'p2p' },
    { content: 'Hello world!', senderId: 'user_004', chatType: 'p2p' },
  ];
  
  console.log('\n' + '-'.repeat(70));
  console.log('测试消息处理');
  console.log('-'.repeat(70));
  
  for (const testMsg of testMessages) {
    console.log(`\n📨 测试消息: "${testMsg.content}"`);
    console.log(`   来自: ${testMsg.senderId} (${testMsg.chatType})`);
    
    try {
      // 模拟调用 OpenCode API
      const systemPrompt = `You are a helpful AI assistant responding to a message from Feishu/Lark.
User ID: ${testMsg.senderId}
Chat Type: ${testMsg.chatType}`;
      
      const result = await mockContext.client!.chat!.completions!.create({
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: testMsg.content }
        ],
        model: 'default'
      });
      
      const response = result.choices[0].message.content;
      console.log(`✅ 回复: "${response.substring(0, 100)}${response.length > 100 ? '...' : ''}"`);
    } catch (error) {
      console.error(`❌ 错误:`, error);
    }
  }
  
  console.log('\n' + '='.repeat(70));
  console.log('集成测试完成');
  console.log('='.repeat(70));
  console.log('\n测试说明:');
  console.log('1. 这个测试模拟了 OpenCode client.chat.completions.create API');
  console.log('2. 实际环境中，插件会尝试调用真实的 OpenCode API');
  console.log('3. 如果 OpenCode API 不可用，插件会回退到备用处理逻辑');
  console.log('4. 确保 OpenCode 已正确配置并拥有可用的 AI provider');
}

/**
 * 测试插件与 OpenCode 工具的集成
 */
async function testToolIntegration() {
  console.log('\n' + '='.repeat(70));
  console.log('工具集成测试');
  console.log('='.repeat(70));
  
  // 这里测试插件提供的工具是否能被 OpenCode 调用
  console.log('\n插件提供的工具:');
  console.log('  1. feishu_send_message - 发送消息到飞书');
  console.log('  2. feishu_reply_message - 回复飞书消息');
  console.log('  3. feishu_gateway_status - 检查网关状态');
  
  console.log('\n在 OpenCode 中，你可以这样调用这些工具:');
  console.log('  • 直接输入: "发送飞书消息到 chat_id 说你好"');
  console.log('  • AI 会自动调用 feishu_send_message 工具');
  console.log('  • 或者在对话中使用 @feishu_send_message');
  
  console.log('\n' + '='.repeat(70));
}

/**
 * 主测试函数
 */
async function main() {
  try {
    await testOpenCodeIntegration();
    await testToolIntegration();
    
    console.log('\n' + '='.repeat(70));
    console.log('所有测试完成 ✨');
    console.log('='.repeat(70));
    console.log('\n下一步:');
    console.log('1. 配置飞书应用并获取 App ID 和 App Secret');
    console.log('2. 在 opencode.json 中配置插件');
    console.log('3. 运行: opencode feishu-gateway');
    console.log('4. 在飞书中测试机器人功能');
    console.log('='.repeat(70));
  } catch (error) {
    console.error('测试失败:', error);
    process.exit(1);
  }
}

// 如果直接运行此文件
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

export { createMockOpenCodeContext, testOpenCodeIntegration };
