// examples/basic-usage.ts
// 基础用法示例：通过代码方式启动飞书网关

import { FeishuGateway, MessageContext } from '../src/index.js';

async function main() {
  // 创建网关实例
  const gateway = new FeishuGateway({
    feishu: {
      appId: process.env.FEISHU_APP_ID || 'cli_xxxxxxxxxxxxxxxx',
      appSecret: process.env.FEISHU_APP_SECRET || 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
      allowFrom: [], // 空数组表示允许所有用户
      replyDelayMode: 'non-mention', // 群聊中需要 @ 才回复
      replyDelayMs: 0,
    },
    onMessage: async (context: MessageContext) => {
      console.log('收到消息:', {
        senderId: context.senderId,
        chatType: context.chatType,
        content: context.content,
        isMentioned: context.isMentioned,
      });

      // 简单的回声回复
      if (context.content === 'ping') {
        return 'pong';
      }

      // 返回帮助信息
      if (context.content === 'help') {
        return `可用命令：
- ping: 测试连接
- help: 显示帮助
- time: 显示当前时间
- 其他: 直接回复消息`;
      }

      // 返回当前时间
      if (context.content === 'time') {
        return `当前时间: ${new Date().toLocaleString('zh-CN')}`;
      }

      // 默认回复
      return `收到消息: ${context.content}`;
    },
  });

  // 启动网关
  console.log('启动飞书网关...');
  await gateway.start();

  // 处理退出信号
  process.on('SIGINT', () => {
    console.log('\n停止飞书网关...');
    gateway.stop();
    process.exit(0);
  });

  process.on('SIGTERM', () => {
    console.log('\n停止飞书网关...');
    gateway.stop();
    process.exit(0);
  });
}

main().catch(console.error);
