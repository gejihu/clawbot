# OpenCode Feishu Bot Plugin

[![npm version](https://img.shields.io/npm/v/opencode-feishu-bot.svg)](https://www.npmjs.com/package/opencode-feishu-bot)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-blue.svg)](https://www.typescriptlang.org/)

让 OpenCode 具备与飞书机器人对话能力的插件。灵感来源于 [nanobot](https://github.com/HKUDS/nanobot) 的飞书集成。

## 功能特性

- **WebSocket 长连接** - 实时接收消息，无需公网 IP
- **私聊和群聊** - 支持个人对话和群组对话
- **@提及触发** - 群聊中可通过 @机器人触发回复
- **白名单控制** - 可限制只有特定用户能访问
- **多种消息类型** - 支持文本、富文本、图片等
- **延迟回复** - 可配置回复延迟，避免过快响应
- **命令系统** - 内置命令扩展机制

## 安装

```bash
npm install opencode-feishu-bot
```

## 快速开始

### 1. 配置飞书应用

1. 访问 [飞书开放平台](https://open.feishu.cn/app)
2. 创建企业自建应用
3. 添加"机器人"能力
4. 配置权限：`im:message:send_as_bot`, `im:message.group_msg`, `im:message.p2p_msg`
5. 添加事件订阅：`im.message.receive_v1`（长连接模式）
6. 获取 **App ID** 和 **App Secret**
7. 发布应用

### 2. 配置 OpenCode

在项目根目录创建 `opencode.json`：

```json
{
  "$schema": "https://opencode.ai/config.json",
  "plugins": ["opencode-feishu-bot"],
  "feishu": {
    "appId": "cli_xxxxxxxxxxxxxxxx",
    "appSecret": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    "allowFrom": [],
    "replyDelayMode": "non-mention",
    "replyDelayMs": 0
  }
}
```

### 3. 启动网关

```bash
opencode feishu-gateway
```

### 4. 开始使用

- **私聊**：在飞书中搜索你的机器人，点击"发消息"
- **群聊**：将机器人添加到群聊，@机器人发送消息

## 配置说明

| 配置项 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| `appId` | string | ✅ | - | 飞书应用 ID |
| `appSecret` | string | ✅ | - | 飞书应用密钥 |
| `encryptKey` | string | ❌ | "" | 加密密钥（可选） |
| `verificationToken` | string | ❌ | "" | 验证令牌（可选） |
| `allowFrom` | string[] | ❌ | [] | 用户白名单，空数组表示允许所有 |
| `replyDelayMode` | string | ❌ | "non-mention" | 群聊回复模式 |
| `replyDelayMs` | number | ❌ | 0 | 回复延迟（毫秒） |

### replyDelayMode 说明

- `"non-mention"` (默认): 群聊中必须 @机器人才回复
- `"always"`: 群聊中所有消息都回复

## OpenCode 集成

本插件深度集成 OpenCode 的核心功能：

### 1. 调用 OpenCode AI Agent

当收到飞书消息时，插件会自动调用 OpenCode 的 AI Agent 生成回复：

```
飞书用户消息 → 插件 → OpenCode Agent → 生成回复 → 发送回飞书
```

**特点**:
- 自动使用 OpenCode 配置的 AI Provider（OpenAI, Claude, etc.）
- 支持 OpenCode 的所有 Agent 功能
- 自动降级处理（如果 OpenCode API 不可用）

### 2. 注册 OpenCode 工具

插件向 OpenCode 注册了 3 个工具，可以被 AI 调用：

| 工具 | 说明 | 示例 |
|------|------|------|
| `feishu_send_message` | 发送飞书消息 | `"发送飞书消息给张三"` |
| `feishu_reply_message` | 回复飞书消息 | `"回复那条消息说好的"` |
| `feishu_gateway_status` | 检查网关状态 | `"检查飞书机器人状态"` |

### 3. 注册 OpenCode 命令

| 命令 | 说明 |
|------|------|
| `opencode feishu-gateway` | 启动飞书网关，接收并回复消息 |
| `opencode feishu-status` | 查看连接和配置状态 |
| `opencode feishu-test <chat-id>` | 发送测试消息 |

## API 使用

### 程序化启动网关

```typescript
import { FeishuGateway, MessageContext } from 'opencode-feishu-bot';

const gateway = new FeishuGateway({
  feishu: {
    appId: 'cli_xxxxxxxxxxxxxxxx',
    appSecret: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
  },
  onMessage: async (context: MessageContext) => {
    // 处理消息并返回回复
    console.log(`收到: ${context.content}`);
    return `回复: ${context.content}`;
  },
});

await gateway.start();
```

### 发送主动消息

```typescript
import { FeishuClient } from 'opencode-feishu-bot';

const client = new FeishuClient({
  appId: 'cli_xxxxxxxxxxxxxxxx',
  appSecret: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
});

await client.sendMessage('chat_id', '主动发送的消息');
```

## 示例

查看 [examples](./examples) 目录获取更多使用示例：

- **basic-usage.ts** - 基础用法
- **with-opencode-agent.ts** - 与 OpenCode Agent 集成
- **custom-handler.ts** - 自定义消息处理器

## 项目结构

```
opencode-feishu-bot/
├── src/
│   ├── index.ts           # 插件入口
│   ├── feishu-client.ts   # 飞书 API 客户端
│   ├── gateway.ts         # 网关逻辑
│   ├── message-handler.ts # 消息处理器
│   └── types.ts           # 类型定义
├── examples/              # 使用示例
├── README.md             # 本文件
├── GUIDE.md              # 详细使用指南
└── package.json
```

## 与 nanobot 的对比

| 特性 | nanobot | opencode-feishu-bot |
|------|---------|---------------------|
| 平台 | Python CLI 工具 | OpenCode 插件 |
| 飞书集成 | ✅ | ✅ |
| 其他平台 | Telegram, Discord, WhatsApp, etc. | 专注于飞书 |
| 架构 | 独立应用 | OpenCode 插件 |
| 代码量 | ~4000 行 | ~800 行 |
| 扩展性 | 修改源码 | 插件配置 |

## 常见问题

### Q: 无法连接到飞书？

A: 检查以下几点：
1. App ID 和 App Secret 是否正确
2. 应用是否已发布
3. 是否正确配置了事件订阅和权限

### Q: 收不到消息？

A: 确保：
1. 使用了"长连接"模式
2. 添加了 `im.message.receive_v1` 事件
3. 机器人已添加到群聊（群聊场景）

### Q: 如何获取用户 ID？

A: 先不配置 `allowFrom` 白名单，让用户发送一条消息，在控制台日志中查看 `senderId`。

## 开发

```bash
# 安装依赖
npm install

# 开发模式
npm run dev

# 构建
npm run build
```

## 贡献

欢迎提交 Issue 和 Pull Request！

## 许可证

MIT © [Your Name]

## 相关链接

- [OpenCode 官网](https://opencode.ai)
- [OpenCode 插件文档](https://opencode.ai/docs/plugins)
- [飞书开放平台](https://open.feishu.cn)
- [nanobot](https://github.com/HKUDS/nanobot) - 灵感来源
