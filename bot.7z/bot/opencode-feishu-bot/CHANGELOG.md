# Changelog

所有重要的变更都会记录在这个文件中。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)，
并且本项目遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [1.0.0] - 2026-02-11

### 新增

- 初始版本发布
- WebSocket 长连接支持飞书消息接收
- 支持私聊和群聊消息处理
- @提及触发群聊回复
- 用户白名单访问控制
- 可配置回复延迟
- 完整的 TypeScript 类型支持
- 三个使用示例
- OpenCode 插件集成
- 命令支持：`feishu-gateway`, `feishu-status`

### 功能

- `FeishuClient` - 飞书 API 客户端
  - 自动 Token 刷新
  - WebSocket 连接管理
  - 自动重连机制
  - 发送消息和回复
  
- `FeishuGateway` - 网关管理
  - 消息事件处理
  - 生命周期管理
  - 错误处理
  
- `MessageHandler` - 消息处理器
  - 消息解析
  - 权限检查
  - 内容格式化

## [Unreleased]

### 计划功能

- [ ] 支持更多消息类型（图片、文件、卡片）
- [ ] 消息历史记录
- [ ] 多轮对话上下文保持
- [ ] 定时任务支持
- [ ] Webhook 集成
- [ ] 支持其他 IM 平台（钉钉、企业微信）
- [ ] 消息模板系统
- [ ] 群管理功能

