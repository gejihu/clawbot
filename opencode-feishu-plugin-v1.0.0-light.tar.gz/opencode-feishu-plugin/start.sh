#!/bin/bash

# OpenCode 飞书插件启动脚本

# 设置工作目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 日志文件
LOG_FILE="/tmp/feishu-plugin.log"
DEBUG_LOG="/tmp/opencode-feishu-debug.log"

echo "🚀 启动 OpenCode 飞书插件..."
echo "日志文件: $LOG_FILE"
echo "调试日志: $DEBUG_LOG"

# 检查是否已经在运行
PID=$(pgrep -f "node bin/cli.js start")
if [ -n "$PID" ]; then
    echo "⚠️ 插件已在运行 (PID: $PID)"
    echo "如需重启，请先运行: ./stop.sh"
    exit 1
fi

# 清空旧日志
> "$LOG_FILE"
> "$DEBUG_LOG"

# 启动插件
nohup node bin/cli.js start > "$LOG_FILE" 2>&1 &
NEW_PID=$!

# 等待几秒检查是否启动成功
sleep 3

if ps -p $NEW_PID > /dev/null; then
    echo "✅ 插件启动成功!"
    echo "PID: $NEW_PID"
    echo ""
    echo "查看日志:"
    echo "  tail -f $LOG_FILE"
    echo "  tail -f $DEBUG_LOG"
    echo ""
    echo "停止插件: ./stop.sh"
else
    echo "❌ 插件启动失败!"
    echo "查看错误日志: $LOG_FILE"
    exit 1
fi
