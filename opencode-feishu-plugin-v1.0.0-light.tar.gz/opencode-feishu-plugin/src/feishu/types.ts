/**
 * 飞书客户端类型定义
 */

import { EventEmitter } from 'events';

export interface FeishuCredentials {
  appId: string;
  appSecret: string;
}

export interface TenantAccessTokenResponse {
  code: number;
  msg: string;
  tenant_access_token: string;
  expire: number;
}

export interface FeishuWebSocketUrlResponse {
  code: number;
  msg: string;
  data: {
    ws_url: string;
  };
}

export interface FeishuSendMessageRequest {
  receive_id: string;
  msg_type: 'text' | 'rich_text' | 'image';
  content: string;
}

export interface FeishuSendMessageResponse {
  code: number;
  msg: string;
  data: {
    message_id: string;
  };
}

export interface FeishuMessageHandler {
  on(event: 'message', listener: (message: any) => void): this;
  on(event: 'error', listener: (error: Error) => void): this;
  on(event: 'close', listener: () => void): this;
}
