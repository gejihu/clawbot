/**
 * 飞书 WebSocket 客户端（使用 Lark SDK）
 */

import { WSClient, EventDispatcher, Client } from '@larksuiteoapi/node-sdk';
import { EventEmitter } from 'events';
import { debugLog, errorLog } from '../utils/logger';
import { FeishuCredentials } from './types';

interface IConstructorParams {
  appId: string;
  appSecret: string;
  loggerLevel?: number;
}

export class FeishuClient extends EventEmitter {
  private wsClient: any = null;
  private apiClient: Client | null = null;
  private credentials: FeishuCredentials;
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 10;
  private reconnectDelay: number = 3000;
  private isConnected: boolean = false;
  private isReadyForEvents: boolean = false;
  private tenantAccessToken: string = '';

  constructor(credentials: FeishuCredentials) {
    super();
    this.credentials = credentials;
  }

  private async getTenantAccessToken(): Promise<string> {
    if (this.tenantAccessToken) {
      return this.tenantAccessToken;
    }

    try {
      const axios = require('axios');
      const response = await axios.post(
        'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
        {
          app_id: this.credentials.appId,
          app_secret: this.credentials.appSecret
        },
        { headers: { 'Content-Type': 'application/json' } }
      );

      if (response.data.code === 0) {
        this.tenantAccessToken = response.data.tenant_access_token;
        debugLog('FEISHU: Got tenant access token');
        return this.tenantAccessToken;
      } else {
        throw new Error(`Failed to get token: ${response.data.msg}`);
      }
    } catch (error) {
      errorLog('FEISHU: Failed to get tenant access token', error);
      throw error;
    }
  }

  async connect(): Promise<void> {
    if (this.isConnected) {
      debugLog('FEISHU: Already connected');
      return;
    }

    try {
      debugLog('FEISHU: Creating WSClient...');

      const params: IConstructorParams = {
        appId: this.credentials.appId,
        appSecret: this.credentials.appSecret,
        loggerLevel: 1
      };

      this.wsClient = new WSClient(params);

      debugLog('FEISHU: WSClient created, starting connection...');

      const eventDispatcher = new EventDispatcher({});

      eventDispatcher.register({
        'im.message.receive_v1': async (data: any) => {
          debugLog(`FEISHU: Received message event`);
          await this.handleMessage(data);
        }
      });

      await this.wsClient.start({ eventDispatcher });

      this.isConnected = true;
      this.emit('open');
      debugLog('FEISHU: Connected successfully');

    } catch (error) {
      errorLog('FEISHU: Connection failed', error);
      this.scheduleReconnect();
      throw error;
    }
  }

  private async handleMessage(data: any): Promise<void> {
    try {
      const message = data;
      const messageId = message.message_id || message.message?.message_id;
      const senderId = message.message?.sender_id?.open_id ||
                       message.sender?.sender_id?.open_id;
      const content = message.message?.content || message.content;

      debugLog(`FEISHU: Message ${messageId} from ${senderId}: ${JSON.stringify(content)?.substring(0, 100)}`);

      if (!senderId) {
        debugLog('FEISHU: No sender ID, skipping');
        return;
      }

      this.setReadyForEvents();
      this.emit('message', {
        message_id: messageId,
        sender: {
          sender_id: { open_id: senderId }
        },
        content: content
      });

    } catch (error) {
      errorLog('FEISHU: Handle message error', error);
    }
  }

  private scheduleReconnect(): void {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      debugLog('FEISHU: Max reconnect attempts reached');
      return;
    }

    this.reconnectAttempts++;
    const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);

    debugLog(`FEISHU: Scheduling reconnect attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts} in ${delay}ms`);

    setTimeout(() => {
      this.connect().catch(() => {});
    }, delay);
  }

  async sendTextMessage(receiverId: string, text: string): Promise<string | null> {
    return this.sendTextMessageHTTP(receiverId, text);
  }

  private async sendTextMessageHTTP(receiverId: string, text: string): Promise<string | null> {
    try {
      const axios = require('axios');
      const token = await this.getTenantAccessToken();

      const response = await axios.post(
        `https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id`,
        {
          receive_id: receiverId,
          msg_type: 'text',
          content: JSON.stringify({ text: text })
        },
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.data.code === 0) {
        debugLog(`FEISHU: Message sent to ${receiverId}`);
        return response.data.data?.message_id || null;
      } else {
        throw new Error(`Send failed: ${response.data.msg}`);
      }
    } catch (error) {
      errorLog('FEISHU: Send message failed', error);
      throw error;
    }
  }

  async addReaction(messageId: string, reactionType: string = 'THUMBS_UP'): Promise<boolean> {
    try {
      const axios = require('axios');
      const token = await this.getTenantAccessToken();

      const response = await axios.post(
        `https://open.feishu.cn/open-apis/im/v1/messages/${messageId}/reactions`,
        {
          reaction_type: { emoji_type: reactionType }
        },
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.data.code === 0) {
        debugLog(`FEISHU: Added reaction ${reactionType} to message ${messageId}`);
        return true;
      } else {
        debugLog(`FEISHU: Failed to add reaction: ${response.data.msg}`);
        return false;
      }
    } catch (error) {
      errorLog('FEISHU: Add reaction failed', error);
      return false;
    }
  }

  async sendQuickAck(receiverId: string): Promise<string | null> {
    try {
      const axios = require('axios');
      const token = await this.getTenantAccessToken();

      const response = await axios.post(
        `https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id`,
        {
          receive_id: receiverId,
          msg_type: 'text',
          content: JSON.stringify({ text: '👍 收到，我正在思考...' })
        },
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      if (response.data.code === 0) {
        debugLog(`FEISHU: Quick ack sent to ${receiverId}`);
        return response.data.data?.message_id || null;
      } else {
        throw new Error(`Send failed: ${response.data.msg}`);
      }
    } catch (error) {
      errorLog('FEISHU: Send quick ack failed', error);
      throw error;
    }
  }

  disconnect(): void {
    if (this.wsClient) {
      try {
        this.wsClient.close({ force: true });
      } catch (error) {
      }
      this.wsClient = null;
    }
    this.tenantAccessToken = '';
    this.isConnected = false;
    debugLog('FEISHU: Disconnected');
  }

  getConnectionStatus(): { connected: boolean; reconnectAttempts: number } {
    return {
      connected: this.isConnected,
      reconnectAttempts: this.reconnectAttempts
    };
  }

  setReadyForEvents(): void {
    this.isReadyForEvents = true;
  }
}
