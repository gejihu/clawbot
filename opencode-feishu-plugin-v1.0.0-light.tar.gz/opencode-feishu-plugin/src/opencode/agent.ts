/**
 * OpenCode Agent 集成模块
 */

import { spawn } from 'child_process';
import * as readline from 'readline';
import { AgentResponse } from '../types';
import { logger, debugLog, errorLog } from '../utils/logger';

export class OpenCodeAgent {
  private opencodePath: string;
  private useMockMode: boolean;
  private apiClient: any = null;
  private serverAvailable: boolean = false;

  constructor(opencodePath?: string) {
    this.opencodePath = opencodePath || 'opencode';
    this.useMockMode = process.env.OPENCODE_MOCK_MODE === 'true';
    debugLog(`AGENT: Constructor - useMockMode=${this.useMockMode}, OPENCODE_MOCK_MODE env=${process.env.OPENCODE_MOCK_MODE}`);
  }

  /**
   * 检查 OpenCode Server 是否可用
   * 自动发现端口并连接
   */
  async checkAvailability(): Promise<boolean> {
    debugLog(`CHECK: Starting availability check, useMockMode=${this.useMockMode}`);

    if (this.useMockMode) {
      debugLog('CHECK: Mock mode enabled, returning false');
      return false;
    }

    try {
      const { OpenCodeAPIClient } = require('./api-client');
      
      // 创建 API 客户端
      debugLog('CHECK: Creating API client...');
      this.apiClient = new OpenCodeAPIClient();
      
      // 首先尝试自动发现端口
      debugLog('CHECK: Discovering OpenCode port...');
      const discovered = await this.apiClient.discoverAndSetPort();
      
      if (!discovered) {
        debugLog('CHECK: Could not discover OpenCode port');
        this.serverAvailable = false;
        return false;
      }
      
      debugLog('CHECK: Calling health check...');
      this.serverAvailable = await this.apiClient.checkHealth();
      debugLog(`CHECK: Health check result: ${this.serverAvailable}`);

      if (this.serverAvailable) {
        debugLog('CHECK: OpenCode Server is available, creating session...');
        await this.apiClient.createSession('feishu-bot');
        debugLog('CHECK: Session created successfully');
        return true;
      } else {
        debugLog('CHECK: OpenCode Server is not available (health check returned false)');
        return false;
      }
    } catch (error) {
      errorLog('CHECK: OpenCode Server check failed', error);
      return false;
    }
  }

  /**
   * 获取可用模型列表
   */
  async getAvailableModels(): Promise<string[]> {
    if (!this.apiClient) {
      debugLog('AGENT: No API client, checking availability first');
      await this.checkAvailability();
    }
    
    if (this.apiClient) {
      return this.apiClient.getAvailableModels();
    }
    
    return [];
  }

  /**
    * 通过 API 与 OpenCode 对话
    */
  async chat(prompt: string, sessionId?: string): Promise<AgentResponse> {
    debugLog(`CHAT: === chat() called ===`);
    debugLog(`CHAT: prompt="${prompt.substring(0, 50)}..."`);
    debugLog(`CHAT: sessionId=${sessionId}`);
    debugLog(`CHAT: useMockMode=${this.useMockMode}, serverAvailable=${this.serverAvailable}, apiClient=${!!this.apiClient}`);

    if (this.useMockMode) {
      debugLog('CHAT: Using mock mode (useMockMode=true)');
      return this.mockChat(prompt);
    }

    if (!this.serverAvailable || !this.apiClient) {
      debugLog('CHAT: Server not available, checking availability...');
      await this.checkAvailability();
      debugLog(`CHAT: After check - serverAvailable=${this.serverAvailable}, apiClient=${!!this.apiClient}`);
    }

    if (this.serverAvailable && this.apiClient) {
      debugLog('CHAT: Calling OpenCode API...');
      try {
        // 使用 agent 自己的 session，不使用外部传入的 sessionId
        debugLog('CHAT: Using agent session for API call');

        debugLog('CHAT: Calling API.chat() with model: opencode/minimax-m2.5-free');
        const response = await this.apiClient.chat(prompt, 'opencode/minimax-m2.5-free');

        debugLog(`CHAT: API response - success=${response.success}, textLength=${response.text?.length || 0}`);

        if (response.success && response.text && response.text.length > 0) {
          debugLog(`CHAT: Returning successful response`);
          return response;
        } else {
          debugLog(`CHAT: API response was not successful or empty`);
          debugLog(`CHAT: Response details: ${JSON.stringify(response)}`);
        }
      } catch (error) {
        errorLog('CHAT: API chat failed with exception', error);
      }
    } else {
      debugLog('CHAT: Server not available even after checking');
    }

    debugLog('CHAT: Falling back to mock response');
    return this.mockChat(prompt);
  }

  /**
   * 模拟响应（用于测试或当 OpenCode 不可用时）
   */
  private mockChat(prompt: string): AgentResponse {
    const responses = [
      "你好！我是 OpenCode AI 助手。很高兴为你服务！",
      "收到你的消息了。目前我使用的是模拟响应模式。",
      "你好！这是一条测试消息。",
      "感谢你的消息！当前运行在测试模式下。",
      "我收到了你的输入。"
    ];

    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    
    return {
      text: `${randomResponse}\n\n---\n*收到的问题：${prompt.substring(0, 50)}${prompt.length > 50 ? '...' : ''}*\n*状态：模拟响应模式*`,
      success: true
    };
  }
}
