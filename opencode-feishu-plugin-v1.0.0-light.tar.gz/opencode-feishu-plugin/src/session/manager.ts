/**
 * 会话管理器
 */

import { v4 as uuidv4 } from 'uuid';
import { logger } from '../utils/logger';
import { Session, Message } from '../types';

export class SessionManager {
  private sessions: Map<string, Session> = new Map();
  private userSessions: Map<string, string> = new Map(); // userId -> sessionId
  private sessionTimeout: number;

  constructor(sessionTimeout: number = 3600000) {
    this.sessionTimeout = sessionTimeout;
  }

  getOrCreateSession(userId: string): Session {
    // 检查是否已有会话
    const existingSessionId = this.userSessions.get(userId);
    if (existingSessionId) {
      const session = this.sessions.get(existingSessionId);
      if (session) {
        // 更新最后活动时间
        session.lastActivity = new Date();
        return session;
      }
    }

    // 创建新会话
    const sessionId = uuidv4();
    const session: Session = {
      id: sessionId,
      userId,
      messages: [],
      createdAt: new Date(),
      lastActivity: new Date()
    };

    this.sessions.set(sessionId, session);
    this.userSessions.set(userId, sessionId);

    logger.debug(`Created new session ${sessionId} for user ${userId}`);
    return session;
  }

  getSession(sessionId: string): Session | null {
    return this.sessions.get(sessionId) || null;
  }

  getSessionByUserId(userId: string): Session | null {
    const sessionId = this.userSessions.get(userId);
    if (!sessionId) return null;
    return this.sessions.get(sessionId) || null;
  }

  addMessage(sessionId: string, role: 'user' | 'assistant' | 'system', content: string): boolean {
    const session = this.sessions.get(sessionId);
    if (!session) {
      logger.warn(`Session ${sessionId} not found`);
      return false;
    }

    session.messages.push({
      role,
      content,
      timestamp: new Date()
    });

    session.lastActivity = new Date();
    return true;
  }

  getConversationHistory(sessionId: string, maxMessages: number = 20): Message[] {
    const session = this.sessions.get(sessionId);
    if (!session) return [];

    const messages = session.messages.slice(-maxMessages);
    return messages;
  }

  buildPrompt(sessionId: string): string {
    const messages = this.getConversationHistory(sessionId, 10);
    
    return messages
      .map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`)
      .join('\n\n');
  }

  isSessionValid(sessionId: string): boolean {
    const session = this.sessions.get(sessionId);
    if (!session) return false;

    const now = Date.now();
    const elapsed = now - session.lastActivity.getTime();
    return elapsed < this.sessionTimeout;
  }

  cleanupExpiredSessions(): number {
    const now = Date.now();
    let removedCount = 0;

    for (const [sessionId, session] of this.sessions) {
      if (now - session.lastActivity.getTime() > this.sessionTimeout) {
        this.sessions.delete(sessionId);
        this.userSessions.delete(session.userId);
        removedCount++;
      }
    }

    if (removedCount > 0) {
      logger.info(`Cleaned up ${removedCount} expired sessions`);
    }

    return removedCount;
  }

  clearSession(sessionId: string): boolean {
    const session = this.sessions.get(sessionId);
    if (!session) return false;

    this.sessions.delete(sessionId);
    this.userSessions.delete(session.userId);
    logger.debug(`Cleared session ${sessionId}`);
    return true;
  }

  clearAllSessions(): void {
    this.sessions.clear();
    this.userSessions.clear();
    logger.info('All sessions cleared');
  }

  getSessionCount(): number {
    return this.sessions.size;
  }
}
