/**
 * 日志工具
 */

import pino, { Logger } from 'pino';
import * as fs from 'fs';
import * as path from 'path';

const logFile = '/tmp/opencode-feishu-debug.log';

function appendLog(msg: string) {
  const timestamp = new Date().toISOString();
  fs.appendFileSync(logFile, `[${timestamp}] ${msg}\n`);
}

let loggerInstance: Logger | null = null;

export function createLogger(options?: {
  level?: string;
  name?: string;
}): Logger {
  if (loggerInstance) {
    return loggerInstance;
  }

  const level = options?.level || process.env.LOG_LEVEL || 'info';
  const name = options?.name || 'opencode-feishu';

  loggerInstance = pino({
    level,
    name,
    transport: process.env.NODE_ENV !== 'production' ? {
      target: 'pino-pretty',
      options: {
        colorize: true
      }
    } : undefined
  });

  return loggerInstance;
}

export const logger = createLogger();

export function debugLog(msg: string) {
  const timestamp = new Date().toISOString();
  const logMsg = `[DEBUG] ${msg}`;
  console.log(logMsg);
  appendLog(logMsg);
}

export function errorLog(msg: string, error?: any) {
  const timestamp = new Date().toISOString();
  const logMsg = `[ERROR] ${msg} ${error ? JSON.stringify(error) : ''}`;
  console.log(logMsg);
  appendLog(logMsg);
}
