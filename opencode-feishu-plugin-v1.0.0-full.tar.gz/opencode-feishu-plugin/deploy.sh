#!/bin/bash

# OpenCode 飞书插件部署脚本

set -e

echo "🚀 OpenCode 飞书插件部署脚本"
echo "=============================="
echo ""

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 检查 Node.js
echo "📦 检查 Node.js..."
if ! command -v node &> /dev/null; then
    echo "❌ 错误: Node.js 未安装"
    echo "请先安装 Node.js 18+"
    exit 1
fi

NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ 错误: Node.js 版本过低 (当前: $(node --version), 需要: 18+)"
    exit 1
fi
echo "✅ Node.js 版本: $(node --version)"

# 检查 npm
echo ""
echo "📦 检查 npm..."
if ! command -v npm &> /dev/null; then
    echo "❌ 错误: npm 未安装"
    exit 1
fi
echo "✅ npm 版本: $(npm --version)"

# 检查 OpenCode
echo ""
echo "🔍 检查 OpenCode..."
OPENCODE_PATH=""

# 尝试查找 opencode
if command -v opencode &> /dev/null; then
    OPENCODE_PATH=$(which opencode)
    echo "✅ 找到 OpenCode: $OPENCODE_PATH"
elif [ -f "$HOME/.opencode/bin/opencode" ]; then
    OPENCODE_PATH="$HOME/.opencode/bin/opencode"
    echo "✅ 找到 OpenCode: $OPENCODE_PATH"
else
    echo "⚠️ 警告: 未找到 OpenCode"
    echo "请先安装 OpenCode: https://github.com/anomalyco/opencode"
    echo ""
    read -p "是否继续部署? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# 安装依赖
echo ""
echo "📦 安装依赖..."
npm install
echo "✅ 依赖安装完成"

# 编译 TypeScript
echo ""
echo "🔨 编译项目..."
npm run build
echo "✅ 编译完成"

# 创建配置文件目录
echo ""
echo "⚙️  配置文件..."
CONFIG_DIR="$HOME/.opencode"
if [ ! -d "$CONFIG_DIR" ]; then
    mkdir -p "$CONFIG_DIR"
    echo "✅ 创建配置目录: $CONFIG_DIR"
fi

# 检查或创建配置文件
CONFIG_FILE="$CONFIG_DIR/config.yaml"
if [ ! -f "$CONFIG_FILE" ]; then
    echo "📝 创建默认配置文件..."
    cat > "$CONFIG_FILE" << 'EOF'
feishu:
  enabled: true
  appId: ""
  appSecret: ""
  allowFrom: []
  sessionTimeout: 3600
  maxMessageLength: 4000
EOF
    echo "✅ 配置文件已创建: $CONFIG_FILE"
    echo "⚠️  请编辑配置文件，填写你的飞书 App ID 和 App Secret"
else
    echo "✅ 配置文件已存在: $CONFIG_FILE"
fi

# 创建启动脚本链接
echo ""
echo "🔗 创建快捷命令..."
INSTALL_DIR="$HOME/.local/bin"
if [ ! -d "$INSTALL_DIR" ]; then
    mkdir -p "$INSTALL_DIR"
fi

# 添加 PATH 检查
if [[ ":$PATH:" != *":$INSTALL_DIR:"* ]]; then
    echo "export PATH=\"$INSTALL_DIR:\$PATH\"" >> "$HOME/.bashrc"
    echo "✅ 已将 $INSTALL_DIR 添加到 PATH"
fi

# 创建启动器脚本
cat > "$INSTALL_DIR/opencode-feishu" << EOF
#!/bin/bash
cd "$SCRIPT_DIR"
./start.sh
EOF
chmod +x "$INSTALL_DIR/opencode-feishu"
echo "✅ 创建快捷命令: opencode-feishu"

# 创建停止器脚本
cat > "$INSTALL_DIR/opencode-feishu-stop" << EOF
#!/bin/bash
cd "$SCRIPT_DIR"
./stop.sh
EOF
chmod +x "$INSTALL_DIR/opencode-feishu-stop"
echo "✅ 创建快捷命令: opencode-feishu-stop"

# 创建状态检查脚本
cat > "$INSTALL_DIR/opencode-feishu-status" << EOF
#!/bin/bash
cd "$SCRIPT_DIR"
./status.sh
EOF
chmod +x "$INSTALL_DIR/opencode-feishu-status"
echo "✅ 创建快捷命令: opencode-feishu-status"

echo ""
echo "🎉 部署完成！"
echo ""
echo "使用说明:"
echo "  启动插件: opencode-feishu"
echo "  停止插件: opencode-feishu-stop"
echo "  查看状态: opencode-feishu-status"
echo ""
echo "或者使用本地脚本:"
echo "  ./start.sh"
echo "  ./stop.sh"
echo "  ./status.sh"
echo ""
echo "查看日志:"
echo "  tail -f /tmp/opencode-feishu-debug.log"
echo ""

# 检查配置
if [ -f "$CONFIG_FILE" ]; then
    if grep -q 'appId: ""' "$CONFIG_FILE" || grep -q 'appSecret: ""' "$CONFIG_FILE"; then
        echo "⚠️  重要提示:"
        echo "   请编辑配置文件: $CONFIG_FILE"
        echo "   填写你的飞书应用凭证:"
        echo "   - appId: 你的飞书 App ID"
        echo "   - appSecret: 你的飞书 App Secret"
        echo ""
    fi
fi

echo "✨ 开始使用前，请确保:"
echo "  1. OpenCode 已安装并运行: opencode serve"
echo "  2. 配置了正确的飞书应用凭证"
echo "  3. 飞书应用已启用机器人功能并配置回调地址"
echo ""
