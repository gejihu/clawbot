#!/bin/bash

# OpenCode 飞书插件状态查看脚本

echo "📊 OpenCode 飞书插件状态"
echo "========================"

# 检查进程
PID=$(pgrep -f "node bin/cli.js start")

if [ -n "$PID" ]; then
    echo "✅ 状态: 运行中"
    echo "PID: $PID"
    echo "启动时间: $(ps -o lstart= -p $PID)"
    echo "内存使用: $(ps -o rss= -p $PID | awk '{print $1/1024 " MB"}')"
else
    echo "❌ 状态: 未运行"
fi

echo ""
echo "日志文件:"
echo "  应用日志: /tmp/feishu-plugin.log"
echo "  调试日志: /tmp/opencode-feishu-debug.log"
echo ""
echo "最近日志 (最后5行):"
echo "-------------------"
tail -5 /tmp/feishu-plugin.log 2>/dev/null || echo "暂无日志"
