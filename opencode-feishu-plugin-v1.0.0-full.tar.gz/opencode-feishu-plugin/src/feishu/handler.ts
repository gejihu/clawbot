/**
 * 飞书消息处理器
 */

import { FeishuClient } from './client';
import { SessionManager } from '../session/manager';
import { MessageFormatter } from '../channel/formatter';
import { OpenCodeAgent } from '../opencode/agent';
import { FeishuConfig } from '../config/schema';
import { FeishuMessage } from '../types';
import { logger, debugLog, errorLog } from '../utils/logger';

export class FeishuMessageHandler {
  private client: FeishuClient;
  private sessionManager: SessionManager;
  private formatter: MessageFormatter;
  private agent: OpenCodeAgent;
  private config: FeishuConfig;
  private isProcessing: Map<string, boolean> = new Map();
  private userModels: Map<string, string> = new Map();

  private availableModels: Array<{id: string, name: string}> = [];
  private modelsLastUpdated: number = 0;

  private async loadAvailableModels(forceRefresh: boolean = false): Promise<void> {
    const now = Date.now();
    const oneHour = 60 * 60 * 1000;
    
    // 如果不需要刷新且缓存有效，直接返回
    if (!forceRefresh && this.availableModels.length > 0 && (now - this.modelsLastUpdated) < oneHour) {
      return;
    }

    try {
      const models = await this.agent.getAvailableModels();
      if (models.length > 0) {
        this.availableModels = models.map(id => ({
          id,
          name: id.split('/').pop() || id
        }));
        this.modelsLastUpdated = now;
        debugLog(`HANDLER: Loaded ${models.length} available models`);
      }
    } catch (error) {
      debugLog(`HANDLER: Failed to load models, using defaults`);
      // 使用默认模型列表
      if (this.availableModels.length === 0) {
        this.availableModels = [
          { id: 'opencode/minimax-m2.5-free', name: 'minimax-m2.5-free' },
          { id: 'opencode/kimi-k2.5-free', name: 'kimi-k2.5-free' },
          { id: 'opencode/gpt-5-nano', name: 'gpt-5-nano' },
          { id: 'opencode/big-pickle', name: 'big-pickle' }
        ];
      }
    }
  }

  constructor(
    client: FeishuClient,
    config: FeishuConfig,
    sessionManager: SessionManager
  ) {
    this.client = client;
    this.config = config;
    this.sessionManager = sessionManager;
    this.formatter = new MessageFormatter();
    this.agent = new OpenCodeAgent();
    
    this.setupClientListeners();
  }

  private setupClientListeners(): void {
    this.client.on('message', async (message: FeishuMessage) => {
      debugLog(`HANDLER: Received message event: ${JSON.stringify(message).substring(0, 200)}`);
      this.client.setReadyForEvents();
      await this.handleMessage(message);
    });

    this.client.on('error', (error: Error) => {
      errorLog('HANDLER: Feishu client error', error);
    });

    this.client.on('close', () => {
      debugLog('HANDLER: Feishu connection closed');
    });
  }

  private async getModelList(): Promise<string> {
    await this.loadAvailableModels();
    return this.availableModels.map(m => `• ${m.name}`).join('\n');
  }

  private async getCurrentModel(userId: string): Promise<string> {
    await this.loadAvailableModels();
    return this.userModels.get(userId) || this.availableModels[0]?.id || 'opencode/minimax-m2.5-free';
  }

  private async isModelCommand(text: string): Promise<{ isCommand: boolean; modelId?: string }> {
    // 检查是否是查询模型列表命令
    if (text.match(/^!models?\s*$/i)) {
      return { isCommand: true, modelId: '__LIST__' };
    }
    
    // 检查是否是刷新模型列表命令
    if (text.match(/^!models?\s+refresh/i)) {
      return { isCommand: true, modelId: '__REFRESH__' };
    }
    
    const match = text.match(/^!model\s+(.+)$/i);
    if (!match) return { isCommand: false };

    const modelName = match[1].trim().toLowerCase();
    await this.loadAvailableModels();
    
    const model = this.availableModels.find(m => 
      m.name.toLowerCase() === modelName || 
      m.id.toLowerCase() === modelName
    );

    if (model) {
      return { isCommand: true, modelId: model.id };
    }
    return { isCommand: true, modelId: undefined };
  }

  async handleMessage(message: FeishuMessage): Promise<void> {
    const userId = message.sender.sender_id.open_id;
    const messageId = message.message_id;

    if (this.isProcessing.get(messageId)) {
      logger.debug(`Message ${messageId} is already being processed`);
      return;
    }

    if (this.config.allowFrom.length > 0 && 
        !this.config.allowFrom.includes(userId)) {
      logger.warn(`User ${userId} is not in the allowed list`);
      return;
    }

    const content = this.formatter.extractText(message.content);
    if (!content) {
      logger.debug('Empty message received');
      return;
    }

    const cleanedContent = this.formatter.cleanUserMessage(content);
    
    if (cleanedContent.length > this.config.maxMessageLength) {
      await this.sendErrorResponse(message, 'Message is too long');
      return;
    }

    this.isProcessing.set(messageId, true);

    debugLog(`HANDLER: cleanedContent="${cleanedContent}"`);

    // 检查是否是模型切换命令
    const modelCmd = await this.isModelCommand(cleanedContent);
    debugLog(`HANDLER: modelCmd.isCommand=${modelCmd.isCommand}, modelCmd.modelId=${modelCmd.modelId}`);
    
    if (modelCmd.isCommand) {
      await this.handleModelCommand(userId, message, modelCmd.modelId);
      this.isProcessing.delete(messageId);
      return;
    }

    // 发送快速确认消息
    try {
      await this.client.sendQuickAck(userId);
      debugLog(`HANDLER: Sent quick ack to ${userId}`);
    } catch (error) {
      debugLog(`HANDLER: Failed to send quick ack: ${error}`);
    }

    try {
      const session = this.sessionManager.getOrCreateSession(userId);
      
      this.sessionManager.addMessage(session.id, 'user', cleanedContent);

      const history = this.sessionManager.buildPrompt(session.id);

      const fullPrompt = history
        ? `${history}\n\nUser: ${cleanedContent}`
        : `User: ${cleanedContent}`;

      const cleanPrompt = fullPrompt.replace(/User:\s*\{["']text["']:\s*["']/g, 'User: ').replace(/\}\s*["']$/g, '').replace(/\\n/g, '\n');

      const currentModel = await this.getCurrentModel(userId);
      const response = await this.agent.chat(cleanPrompt, currentModel);

      if (response.success) {
        let responseText = response.text;
        
        const maxLength = this.config.maxMessageLength;
        if (responseText.length > maxLength) {
          const chunks = this.formatter.splitLongMessage(responseText, maxLength);
          
          for (const chunk of chunks) {
            await this.client.sendTextMessage(userId, chunk);
          }
        } else {
          await this.client.sendTextMessage(userId, responseText);
        }

        this.sessionManager.addMessage(session.id, 'assistant', responseText);
      } else {
        await this.sendErrorResponse(message, response.error || 'Failed to get response');
      }

    } catch (error) {
      logger.error('Error processing message:', error);
      await this.sendErrorResponse(message, 'An error occurred while processing your request');
    } finally {
      this.isProcessing.delete(messageId);
    }
  }

  private async handleModelCommand(userId: string, message: FeishuMessage, modelId: string | undefined): Promise<void> {
    // 查询可用模型列表
    if (modelId === '__LIST__') {
      const currentModel = await this.getCurrentModel(userId);
      const modelList = await this.getModelList();
      
      await this.client.sendTextMessage(userId, 
        `📋 OpenCode 可用模型：\n\n${modelList}\n\n当前使用：${currentModel}\n\n切换模型：!model <模型名>\n刷新列表：!models refresh`
      );
      return;
    }
    
    // 刷新模型列表
    if (modelId === '__REFRESH__') {
      await this.loadAvailableModels(true);
      const modelList = await this.getModelList();
      await this.client.sendTextMessage(userId, 
        `🔄 模型列表已刷新！\n\n可用模型：\n${modelList}`
      );
      return;
    }
    
    if (!modelId) {
      const availableModels = await this.getModelList();
      await this.client.sendTextMessage(userId, 
        `❌ 无效的模型名称！\n\n可用模型：\n${availableModels}\n\n使用方法：!model <模型名>\n例如：!model minimax-m2.5-free`
      );
      return;
    }

    // 切换模型
    await this.loadAvailableModels();
    const model = this.availableModels.find(m => 
      m.id === modelId || m.name.toLowerCase() === modelId.toLowerCase()
    );
    
    if (model) {
      this.userModels.set(userId, model.id);
      
      await this.client.sendTextMessage(userId, 
        `✅ 已切换模型：${model.name}\n\n当前使用：${model.id}`
      );
    } else {
      await this.client.sendTextMessage(userId, 
        `❌ 无效的模型名称！\n\n可用模型：\n${await this.getModelList()}\n\n使用方法：!model <模型名>`
      );
    }
  }

  private async sendErrorResponse(message: FeishuMessage, errorText: string): Promise<void> {
    const userId = message.sender.sender_id.open_id;
    await this.client.sendTextMessage(userId, `Error: ${errorText}`);
  }

  async checkOpenCodeAvailability(): Promise<boolean> {
    return this.agent.checkAvailability();
  }
}
