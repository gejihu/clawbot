/**
 * 消息格式化器
 */

import { logger } from '../utils/logger';

export class MessageFormatter {
  /**
   * 清理用户消息，移除 @机器人前缀
   */
  cleanUserMessage(message: string, botName?: string): string {
    let cleaned = message.trim();

    // 移除 @机器人 或 @botname
    const atPattern = botName 
      ? new RegExp(`^@${botName}\\s*`, 'i')
      : /^@\S+\s*/;
    
    cleaned = cleaned.replace(atPattern, '');

    return cleaned.trim();
  }

  /**
   * 将 OpenCode 响应格式化为飞书消息
   */
  formatForFeishu(text: string): string {
    // 处理 Markdown 代码块
    let formatted = this.formatCodeBlocks(text);
    
    // 处理粗体和斜体
    formatted = this.formatEmphasis(formatted);
    
    // 处理列表
    formatted = this.formatLists(formatted);
    
    return JSON.stringify({ text: formatted });
  }

  private formatCodeBlocks(text: string): string {
    // 替换 ```code``` 为飞书支持的代码格式
    return text.replace(/```(\w*)\n([\s\S]*?)```/g, (_, lang, code) => {
      const cleanCode = code.trim();
      return `\`\`\`${lang}\n${cleanCode}\n\`\`\``;
    });
  }

  private formatEmphasis(text: string): string {
    // 粗体 **text** -> **text**
    let result = text.replace(/\*\*(.*?)\*\*/g, '**$1**');
    // 斜体 *text* -> *text*
    result = result.replace(/\*(.*?)\*/g, '*$1*');
    return result;
  }

  private formatLists(text: string): string {
    // 保持列表格式
    return text;
  }

  /**
    * 从飞书消息中提取纯文本
    */
  extractText(content: any): string {
    if (typeof content === "string") {
      try {
        const parsed = JSON.parse(content);
        if (parsed?.text) {
          return parsed.text;
        }
      } catch {
        return content;
      }
    }

    if (content?.text) {
      return content.text;
    }

    return '';
  }

  /**
   * 截断过长消息
   */
  truncate(text: string, maxLength: number): string {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength - 3) + '...';
  }

  /**
   * 将长消息拆分为多条
   */
  splitLongMessage(text: string, maxLength: number = 4000): string[] {
    const chunks: string[] = [];
    let remaining = text;

    while (remaining.length > maxLength) {
      // 找到合适的分割点
      let chunk = remaining.substring(0, maxLength);
      
      // 尝试在段落边界分割
      const newlineIndex = chunk.lastIndexOf('\n');
      const spaceIndex = chunk.lastIndexOf(' ');
      
      let splitIndex = maxLength;
      if (newlineIndex > maxLength * 0.8) {
        splitIndex = newlineIndex;
      } else if (spaceIndex > maxLength * 0.8) {
        splitIndex = spaceIndex;
      }

      chunks.push(remaining.substring(0, splitIndex).trim());
      remaining = remaining.substring(splitIndex).trim();
    }

    if (remaining) {
      chunks.push(remaining);
    }

    return chunks;
  }

  /**
   * 处理消息中的特殊字符
   */
  sanitize(text: string): string {
    // 移除或替换可能导致问题的字符
    return text
      .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '') // 控制字符
      .replace(/\uFFFD/g, ''); // 替换字符
  }
}
