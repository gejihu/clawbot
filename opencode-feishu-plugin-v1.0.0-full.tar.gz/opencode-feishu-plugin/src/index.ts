/**
 * 飞书插件主入口
 */

import { FeishuClient } from './feishu/client';
import { FeishuMessageHandler } from './feishu/handler';
import { SessionManager } from './session/manager';
import { ConfigLoader } from './config/loader';
import { FeishuConfig } from './config/schema';
import { logger } from './utils/logger';

export class FeishuPlugin {
  private client: FeishuClient | null = null;
  private handler: FeishuMessageHandler | null = null;
  private sessionManager: SessionManager;
  private config: FeishuConfig;
  private isRunning: boolean = false;

  constructor(config?: FeishuConfig) {
    this.config = config || new ConfigLoader().loadFeishuConfig();
    this.sessionManager = new SessionManager(this.config.sessionTimeout * 1000);
  }

  async start(): Promise<void> {
    if (this.isRunning) {
      logger.warn('Plugin is already running');
      return;
    }

    if (!this.config.enabled) {
      logger.warn('Feishu plugin is not enabled in configuration');
      return;
    }

    logger.info('Starting Feishu plugin...');

    try {
      // 创建飞书客户端
      this.client = new FeishuClient({
        appId: this.config.appId,
        appSecret: this.config.appSecret
      });

      // 创建消息处理器
      this.handler = new FeishuMessageHandler(
        this.client,
        this.config,
        this.sessionManager
      );

      // 检查 OpenCode 可用性
      const opencodeAvailable = await this.handler.checkOpenCodeAvailability();
      if (!opencodeAvailable) {
        logger.warn('OpenCode is not available. Please ensure OpenCode is installed.');
      }

      // 连接飞书
      await this.client.connect();

      this.isRunning = true;
      logger.info('Feishu plugin started successfully');

      // 设置定期清理过期会话
      setInterval(() => {
        this.sessionManager.cleanupExpiredSessions();
      }, 60000); // 每分钟清理一次

    } catch (error) {
      logger.error('Failed to start Feishu plugin:', error);
      throw error;
    }
  }

  async stop(): Promise<void> {
    if (!this.isRunning) {
      return;
    }

    logger.info('Stopping Feishu plugin...');

    if (this.client) {
      this.client.disconnect();
      this.client = null;
    }

    this.handler = null;
    this.isRunning = false;

    logger.info('Feishu plugin stopped');
  }

  getStatus(): { running: boolean; sessions: number; connected: boolean } {
    const connectionStatus = this.client?.getConnectionStatus();
    
    return {
      running: this.isRunning,
      sessions: this.sessionManager.getSessionCount(),
      connected: connectionStatus?.connected || false
    };
  }

  async restart(): Promise<void> {
    await this.stop();
    await this.start();
  }
}

// 便捷函数：快速启动插件
export async function startPlugin(configPath?: string): Promise<FeishuPlugin> {
  const loader = new ConfigLoader(configPath);
  const config = loader.loadFeishuConfig();
  
  const plugin = new FeishuPlugin(config);
  await plugin.start();
  
  return plugin;
}
