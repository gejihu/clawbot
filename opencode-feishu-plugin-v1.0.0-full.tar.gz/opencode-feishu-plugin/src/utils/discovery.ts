/**
 * OpenCode 服务发现和模型管理工具
 */

import { debugLog, errorLog } from './logger';

export class OpenCodeDiscovery {
  private cachedPort: number | null = null;
  private cachedModels: string[] = [];
  private lastModelUpdate: number = 0;

  /**
   * 自动发现 OpenCode serve 端口
   * 尝试常见端口或从进程中查找
   */
  async discoverPort(): Promise<number | null> {
    // 如果已经有缓存的端口，先检查是否仍然可用
    if (this.cachedPort) {
      if (await this.testPort(this.cachedPort)) {
        debugLog(`DISCOVERY: Using cached port ${this.cachedPort}`);
        return this.cachedPort;
      }
      this.cachedPort = null;
    }

    // 尝试从进程列表中查找 opencode serve 的端口
    const processPort = await this.findPortFromProcess();
    if (processPort) {
      debugLog(`DISCOVERY: Found port from process: ${processPort}`);
      this.cachedPort = processPort;
      return processPort;
    }

    // 尝试常见的端口
    const commonPorts = [41851, 4097, 4096, 8080, 3000];
    for (const port of commonPorts) {
      if (await this.testPort(port)) {
        debugLog(`DISCOVERY: Found working port: ${port}`);
        this.cachedPort = port;
        return port;
      }
    }

    errorLog('DISCOVERY: Could not find OpenCode serve port');
    return null;
  }

  /**
   * 测试指定端口是否可用
   */
  private async testPort(port: number): Promise<boolean> {
    try {
      const axios = require('axios');
      const response = await axios.get(`http://127.0.0.1:${port}/global/health`, {
        auth: { username: 'opencode', password: 'test123' },
        timeout: 2000
      });
      return response.data?.healthy === true;
    } catch {
      return false;
    }
  }

  /**
   * 从进程列表中查找 opencode serve 端口
   */
  private async findPortFromProcess(): Promise<number | null> {
    try {
      const { execSync } = require('child_process');
      
      // 使用 netstat 或 ss 查找 opencode 进程监听的端口
      let output: string;
      try {
        output = execSync('netstat -tlnp 2>/dev/null | grep opencode || ss -tlnp | grep opencode', { encoding: 'utf8' });
      } catch {
        // 如果命令失败，尝试另一种方式
        output = execSync('lsof -i -P -n | grep opencode | grep LISTEN', { encoding: 'utf8', timeout: 5000 });
      }

      // 解析端口号
      const lines = output.split('\n');
      for (const line of lines) {
        // 匹配 127.0.0.1:PORT 或 :::PORT
        const match = line.match(/(?:127\.0\.0\.1|:::):(\d+)/);
        if (match) {
          const port = parseInt(match[1], 10);
          // 排除 4096 (web UI 端口)
          if (port !== 4096 && await this.testPort(port)) {
            return port;
          }
        }
      }
    } catch (error) {
      debugLog(`DISCOVERY: Failed to find port from process: ${error}`);
    }
    return null;
  }

  /**
   * 获取可用模型列表
   * 优先使用缓存，每小时自动刷新
   */
  async getAvailableModels(forceRefresh: boolean = false): Promise<string[]> {
    const now = Date.now();
    const oneHour = 60 * 60 * 1000;

    // 如果缓存有效且不强制刷新，返回缓存
    if (!forceRefresh && this.cachedModels.length > 0 && (now - this.lastModelUpdate) < oneHour) {
      debugLog(`DISCOVERY: Using cached models (${this.cachedModels.length} models)`);
      return this.cachedModels;
    }

    // 刷新模型列表
    const models = await this.fetchModelsFromCLI();
    if (models.length > 0) {
      this.cachedModels = models;
      this.lastModelUpdate = now;
      debugLog(`DISCOVERY: Updated models list (${models.length} models)`);
    }

    return this.cachedModels;
  }

  /**
   * 从 OpenCode CLI 获取模型列表
   */
  private async fetchModelsFromCLI(): Promise<string[]> {
    try {
      const { execSync } = require('child_process');
      const output = execSync('~/.opencode/bin/opencode models 2>&1', { 
        encoding: 'utf8', 
        timeout: 10000 
      });
      
      // 解析模型列表
      const models = output
        .split('\n')
        .map((line: string) => line.trim())
        .filter((line: string) => line && !line.includes('Error') && !line.includes('Usage'));

      return models;
    } catch (error) {
      errorLog('DISCOVERY: Failed to fetch models from CLI', error);
      return this.cachedModels.length > 0 ? this.cachedModels : [
        'opencode/minimax-m2.5-free',
        'opencode/kimi-k2.5-free',
        'opencode/gpt-5-nano',
        'opencode/big-pickle'
      ];
    }
  }

  /**
   * 清除缓存
   */
  clearCache(): void {
    this.cachedPort = null;
    this.cachedModels = [];
    this.lastModelUpdate = 0;
    debugLog('DISCOVERY: Cache cleared');
  }
}
