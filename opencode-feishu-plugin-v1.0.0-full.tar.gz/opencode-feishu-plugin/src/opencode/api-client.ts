/**
 * OpenCode HTTP API 客户端
 */

const axios = require('axios');
import { debugLog, errorLog } from '../utils/logger';
import { OpenCodeDiscovery } from '../utils/discovery';
import { AgentResponse } from '../types';

export class OpenCodeAPIClient {
  private baseUrl: string;
  private auth: any;
  private sessionId: string | null = null;
  private discovery: OpenCodeDiscovery;

  constructor(config?: { baseUrl?: string; port?: number; username?: string; password?: string }) {
    this.discovery = new OpenCodeDiscovery();
    // 先使用传入的端口或默认端口，后续可以动态更新
    this.baseUrl = (config?.baseUrl || 'http://127.0.0.1') + ':' + (config?.port || 41851);
    this.auth = {
      username: config?.username || 'opencode',
      password: config?.password || 'test123'
    };
  }

  /**
   * 发现并设置正确的端口
   */
  async discoverAndSetPort(): Promise<boolean> {
    const port = await this.discovery.discoverPort();
    if (port) {
      this.baseUrl = `http://127.0.0.1:${port}`;
      debugLog(`API: Discovered OpenCode on port ${port}`);
      return true;
    }
    return false;
  }

  /**
   * 获取可用模型列表
   */
  async getAvailableModels(): Promise<string[]> {
    return this.discovery.getAvailableModels();
  }

  async checkHealth(): Promise<boolean> {
    try {
      const response = await axios.get(`${this.baseUrl}/global/health`, { auth: this.auth });
      debugLog(`API: Health check response: ${JSON.stringify(response.data).substring(0, 100)}`);
      return response.data.healthy === true;
    } catch (error: unknown) {
      errorLog('API: Health check failed', error);
      return false;
    }
  }

  async createSession(title?: string): Promise<string> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/session`,
        { title: title || 'feishu-session' },
        { auth: this.auth }
      );
      debugLog(`API: Create session response: ${JSON.stringify(response.data).substring(0, 200)}`);
      this.sessionId = response.data?.id;
      if (this.sessionId) {
        debugLog(`API: Created session: ${this.sessionId}`);
        return this.sessionId;
      }
      throw new Error('No session ID in response');
    } catch (error: unknown) {
      errorLog('API: Failed to create session', error);
      throw error;
    }
  }

  async sendMessage(content: string, model?: string): Promise<AgentResponse> {
    debugLog(`API: sendMessage() called with model=${model}, content="${content.substring(0, 50)}..."`);
    const sessionId = this.sessionId || await this.createSession();
    debugLog(`API: Using sessionId=${sessionId}`);

    try {
      const body: any = {
        parts: [{ type: 'text', text: content }]
      };

      if (model) {
        const [providerID, modelID] = model.includes('/') ? model.split('/') : ['zen', model];
        body.model = { providerID, modelID };
        debugLog(`API: Using model ${providerID}/${modelID}`);
      }

      debugLog(`API: Sending POST request to ${this.baseUrl}/session/${sessionId}/message`);
      const response = await axios.post(
        `${this.baseUrl}/session/${sessionId}/message`,
        body,
        { auth: this.auth }
      );

      debugLog(`API: Message response status=${response.status}, data=${JSON.stringify(response.data).substring(0, 200)}`);

      // 处理不同的响应格式
      let parts: any[] = [];

      if (Array.isArray(response.data)) {
        parts = response.data;
      } else if (Array.isArray(response.data?.parts)) {
        parts = response.data.parts;
      } else if (Array.isArray(response.data?.info?.parts)) {
        parts = response.data.info.parts;
      }

      const text = parts
        .filter((p: any) => p.type === 'text' && p.text)
        .map((p: any) => p.text)
        .join('');

      const success = text.length > 0;
      debugLog(`API: Extracted text: "${text.substring(0, 50)}...", success=${success}`);
      return { text: text.trim(), success };

    } catch (error: unknown) {
      errorLog('API: Failed to send message', error);
      return { text: '', success: false, error: (error as Error).message };
    }
  }

  async chat(prompt: string, model?: string): Promise<AgentResponse> {
    return this.sendMessage(prompt, model);
  }

  setSession(sessionId: string): void {
    this.sessionId = sessionId;
    debugLog(`API: Session set to: ${sessionId}`);
  }
}
