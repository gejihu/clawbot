/**
 * 配置加载器
 */

import * as fs from 'fs';
import * as path from 'path';
import * as yaml from 'js-yaml';
import { PluginConfig, PluginConfigSchema, FeishuConfig, FeishuConfigSchema } from './schema';
import { logger } from '../utils/logger';

export class ConfigLoader {
  private configPath: string;

  constructor(configPath?: string) {
    this.configPath = configPath || this.getDefaultConfigPath();
  }

  private getDefaultConfigPath(): string {
    const homeDir = process.env.HOME || process.env.USERPROFILE || '.';
    return path.join(homeDir, '.opencode', 'config.yaml');
  }

  load(): PluginConfig {
    try {
      if (!fs.existsSync(this.configPath)) {
        logger.warn(`Config file not found: ${this.configPath}`);
        return this.getDefaultConfig();
      }

      const fileContent = fs.readFileSync(this.configPath, 'utf-8');
      const rawConfig = yaml.load(fileContent) as any;
      
      // 处理嵌套的 feishu 配置
      const configData = {
        feishu: rawConfig.feishu || rawConfig
      };

      const result = PluginConfigSchema.safeParse(configData);
      
      if (!result.success) {
        logger.error('Config validation failed:', result.error.errors);
        throw new Error(`Invalid configuration: ${result.error.message}`);
      }

      logger.info('Configuration loaded successfully');
      return result.data;
    } catch (error) {
      logger.error('Failed to load config:', error);
      throw error;
    }
  }

  private getDefaultConfig(): PluginConfig {
    return {
      feishu: {
        enabled: false,
        appId: '',
        appSecret: '',
        allowFrom: [],
        sessionTimeout: 3600,
        maxMessageLength: 4000
      }
    };
  }

  loadFeishuConfig(): FeishuConfig {
    const config = this.load();
    return config.feishu;
  }

  save(config: PluginConfig): void {
    const dir = path.dirname(this.configPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    const yamlContent = yaml.dump(config, { indent: 2 });
    fs.writeFileSync(this.configPath, yamlContent);
    logger.info(`Configuration saved to ${this.configPath}`);
  }

  validate(config: any): { valid: boolean; errors: string[] } {
    const result = PluginConfigSchema.safeParse(config);
    
    if (result.success) {
      return { valid: true, errors: [] };
    }

    const errors = result.error.errors.map(err => 
      `${err.path.join('.')}: ${err.message}`
    );

    return { valid: false, errors };
  }
}

// 默认配置示例
export const defaultConfig: PluginConfig = {
  feishu: {
    enabled: false,
    appId: '',
    appSecret: '',
    allowFrom: [],
    sessionTimeout: 3600,
    maxMessageLength: 4000
  }
};
