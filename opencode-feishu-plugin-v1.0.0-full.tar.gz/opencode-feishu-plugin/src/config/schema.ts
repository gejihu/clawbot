/**
 * 飞书插件配置模式定义
 */

import { z } from 'zod';

export const FeishuConfigSchema = z.object({
  enabled: z.boolean().default(false),
  appId: z.string().min(1, 'App ID is required'),
  appSecret: z.string().min(1, 'App Secret is required'),
  encryptKey: z.string().optional(),
  verificationToken: z.string().optional(),
  allowFrom: z.array(z.string()).default([]),
  sessionTimeout: z.number().min(60).max(86400).default(3600),
  maxMessageLength: z.number().min(100).max(10000).default(4000),
  rateLimit: z.object({
    maxRequests: z.number().min(1).max(100).default(10),
    windowMs: z.number().min(1000).max(60000).default(60000)
  }).optional(),
  logging: z.object({
    level: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
    format: z.enum(['json', 'pretty']).default('pretty')
  }).optional()
});

export type FeishuConfig = z.infer<typeof FeishuConfigSchema>;

export const PluginConfigSchema = z.object({
  feishu: FeishuConfigSchema
});

export type PluginConfig = z.infer<typeof PluginConfigSchema>;
