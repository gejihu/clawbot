/**
 * 飞书消息事件类型定义
 */

export interface FeishuConfig {
  enabled: boolean;
  appId: string;
  appSecret: string;
  encryptKey?: string;
  verificationToken?: string;
  allowFrom: string[];
  sessionTimeout: number;
  maxMessageLength: number;
  rateLimit?: {
    maxRequests: number;
    windowMs: number;
  };
}

export interface FeishuMessage {
  message_id: string;
  root_id?: string;
  parent_id?: string;
  create_time: string;
  chat_type: 'p2p' | 'group';
  chat_id: string;
  sender: {
    sender_id: {
      open_id: string;
      user_id?: string;
    };
    sender_type: 'user' | 'bot';
  };
  receiver?: {
    receiver_id: {
      open_id: string;
      user_id?: string;
    };
  };
  message_type: 'text' | 'image' | 'audio' | 'file' | 'rich_text' | 'card';
  content: {
    text?: string;
    image_key?: string;
    file_key?: string;
    rich_text?: string;
  };
}

export interface FeishuEvent {
  schema: string;
  header: {
    event_id: string;
    event_type: string;
    create_time: string;
    token: string;
  };
  event: FeishuMessage;
}

export interface FeishuResponse {
  code: number;
  msg: string;
  data?: any;
}

export interface Session {
  id: string;
  userId: string;
  messages: Message[];
  createdAt: Date;
  lastActivity: Date;
}

export interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
}

export interface AgentResponse {
  text: string;
  success: boolean;
  error?: string;
}
