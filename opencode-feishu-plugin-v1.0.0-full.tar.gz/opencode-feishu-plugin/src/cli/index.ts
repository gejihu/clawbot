#!/usr/bin/env node

/**
 * Feishu 插件 CLI 入口
 */

import * as path from 'path';
import * as fs from 'fs';
import { Command } from 'commander';
import { FeishuPlugin } from '../index';
import { ConfigLoader } from '../config/loader';
import { FeishuConfigSchema } from '../config/schema';
import { logger } from '../utils/logger';
import { OpenCodeAgent } from '../opencode/agent';

const packageJson = JSON.parse(
  fs.readFileSync(path.join(__dirname, '../../package.json'), 'utf-8')
);

const program = new Command();

program
  .name('opencode-feishu')
  .description('OpenCode Feishu/Lark Integration Plugin')
  .version(packageJson.version);

program
  .command('start')
  .description('Start the Feishu plugin')
  .option('-c, --config <path>', 'Path to config file')
  .action(async (options) => {
    logger.info('Starting Feishu plugin...');
    
    try {
      const loader = new ConfigLoader(options.config);
      const config = loader.loadFeishuConfig();

      if (!config.enabled) {
        logger.error('Feishu plugin is not enabled. Please set enabled: true in config.');
        process.exit(1);
      }

      if (!config.appId || !config.appSecret) {
        logger.error('App ID and App Secret are required in config.');
        process.exit(1);
      }

      const plugin = new FeishuPlugin(config);
      await plugin.start();

      logger.info('Feishu plugin is running. Press Ctrl+C to stop.');

      // 保持进程运行
      process.on('SIGINT', async () => {
        logger.info('Received SIGINT, shutting down...');
        await plugin.stop();
        process.exit(0);
      });

      process.on('SIGTERM', async () => {
        logger.info('Received SIGTERM, shutting down...');
        await plugin.stop();
        process.exit(0);
      });

      // 保持主进程运行
      await new Promise(() => {});
      
    } catch (error) {
      logger.error('Failed to start plugin:', error);
      process.exit(1);
    }
  });

program
  .command('stop')
  .description('Stop the running Feishu plugin')
  .action(async () => {
    logger.info('Stop command received (requires running instance with IPC or database)');
    logger.info('Use Ctrl+C to stop the foreground process');
  });

program
  .command('status')
  .description('Check plugin status')
  .option('-c, --config <path>', 'Path to config file')
  .action(async (options) => {
    try {
      const loader = new ConfigLoader(options.config);
      const config = loader.loadFeishuConfig();

      console.log('\n=== Feishu Plugin Status ===\n');
      console.log(`Enabled: ${config.enabled ? 'Yes' : 'No'}`);
      console.log(`App ID: ${config.appId ? '***' + config.appId.slice(-4) : 'Not configured'}`);
      console.log(`Session Timeout: ${config.sessionTimeout}s`);
      console.log(`Max Message Length: ${config.maxMessageLength}`);

      // 检查 OpenCode
      const agent = new OpenCodeAgent();
      const opencodeAvailable = await agent.checkAvailability();
      console.log(`\nOpenCode: ${opencodeAvailable ? 'Available' : 'Not found'}`);

      console.log('\n============================\n');
      
    } catch (error) {
      logger.error('Failed to get status:', error);
      process.exit(1);
    }
  });

program
  .command('init')
  .description('Initialize configuration file')
  .option('-c, --config <path>', 'Path to config file')
  .action(async (options) => {
    const configPath = options.config || path.join(process.env.HOME || '.', '.opencode', 'config.yaml');
    
    const defaultConfig = {
      feishu: {
        enabled: false,
        appId: 'your-app-id',
        appSecret: 'your-app-secret',
        allowFrom: [],
        sessionTimeout: 3600,
        maxMessageLength: 4000
      }
    };

    const fs = require('fs');
    const yaml = require('js-yaml');
    
    const dir = path.dirname(configPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    fs.writeFileSync(configPath, yaml.dump(defaultConfig, { indent: 2 }));
    
    logger.info(`Configuration file created at ${configPath}`);
    logger.info('Please edit the file and set your Feishu App credentials');
  });

program
  .command('test')
  .description('Test Feishu connection')
  .option('-c, --config <path>', 'Path to config file')
  .action(async (options) => {
    try {
      const loader = new ConfigLoader(options.config);
      const config = loader.loadFeishuConfig();

      if (!config.appId || !config.appSecret) {
        logger.error('App ID and App Secret are required');
        process.exit(1);
      }

      logger.info('Testing Feishu connection...');
      
      const axios = require('axios');
      const response = await axios.post(
        'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
        {
          app_id: config.appId,
          app_secret: config.appSecret
        },
        { headers: { 'Content-Type': 'application/json' } }
      );

      if (response.data.code === 0) {
        logger.info('✓ Feishu connection successful!');
        logger.info(`Token expires in ${response.data.expire} seconds`);
      } else {
        logger.error(`✗ Feishu connection failed: ${response.data.msg}`);
        process.exit(1);
      }
      
    } catch (error) {
      logger.error('Connection test failed:', (error as Error).message);
      process.exit(1);
    }
  });

program
  .command('setup')
  .description('Setup mode: connect to Feishu and wait for event subscription configuration')
  .option('-c, --config <path>', 'Path to config file')
  .option('-t, --timeout <seconds>', 'Timeout in seconds', '120')
  .action(async (options) => {
    console.log(`
╔════════════════════════════════════════════════════════════════════╗
║                    OpenCode Feishu Plugin Setup                    ║
╠════════════════════════════════════════════════════════════════════╣
║                                                                    ║
║  This mode helps you configure the Feishu event subscription.     ║
║                                                                    ║
║  Steps:                                                            ║
║  1. Plugin will connect to Feishu and wait for events             ║
║  2. Go to Feishu Open Platform                                     ║
║  3. Add event: im.message.receive_v1                               ║
║  4. Select "Long Connection" mode                                  ║
║  5. Save the configuration                                         ║
║  6. Once connected, this will exit automatically                   ║
║                                                                    ║
╚════════════════════════════════════════════════════════════════════╝
`);
    
    try {
      const loader = new ConfigLoader(options.config);
      const config = loader.loadFeishuConfig();

      if (!config.appId || !config.appSecret) {
        logger.error('App ID and App Secret are required');
        process.exit(1);
      }

      const timeoutMs = parseInt(options.timeout) * 1000;
      
      logger.info('Connecting to Feishu...');
      
      // 直接使用客户端
      const { FeishuClient } = require('../feishu/client');
      const client = new FeishuClient({
        appId: config.appId,
        appSecret: config.appSecret
      });

      // 监听连接状态
      client.on('open', () => {
        logger.info('✓ Connected to Feishu!');
        logger.info('Now you can save the event subscription configuration in Feishu Open Platform.');
      });

      client.on('message', (message: any) => {
        logger.info('✓ Received event from Feishu - configuration successful!');
        logger.info('Setup complete. You can now use the plugin normally.');
        process.exit(0);
      });

      client.on('error', (error: Error) => {
        logger.error('Connection error:', error.message);
      });

      // 启动连接
      await client.connect();

      // 等待配置完成
      logger.info(`Waiting for event subscription (timeout: ${options.timeout}s)...`);
      const success = await client.waitForEventSubscription(timeoutMs);

      if (!success) {
        console.log(`
╔════════════════════════════════════════════════════════════════════╗
║                       Setup Timeout                                ║
╠════════════════════════════════════════════════════════════════════╣
║                                                                    ║
║  The setup timed out. Possible reasons:                           ║
║  • You haven't saved the event subscription in Feishu             ║
║  • Network issues                                                 ║
║  • Incorrect configuration                                         ║
║                                                                    ║
║  Please try again or use 'start' command to run normally.         ║
║                                                                    ║
╚════════════════════════════════════════════════════════════════════╝
`);
        client.disconnect();
        process.exit(1);
      }
      
    } catch (error) {
      logger.error('Setup failed:', error);
      process.exit(1);
    }
  });

program.parse(process.argv);

// 如果没有提供命令，显示帮助
if (process.argv.length === 2) {
  program.help();
}
