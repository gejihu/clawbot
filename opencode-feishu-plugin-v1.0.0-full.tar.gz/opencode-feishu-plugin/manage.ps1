# OpenCode 飞书插件 - Windows PowerShell 管理脚本
param(
    [Parameter()]
    [ValidateSet("start", "stop", "status", "restart", "deploy")]
    [string]$Action = "status"
)

$PluginName = "OpenCode 飞书插件"
$LogFile = "$env:TEMP\feishu-plugin.log"
$DebugLog = "$env:TEMP\opencode-feishu-debug.log"

function Show-Status {
    Write-Host "`n📊 $PluginName 状态" -ForegroundColor Cyan
    Write-Host "========================" -ForegroundColor Cyan
    
    $process = Get-Process -Name "node" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*cli.js*" }
    
    if ($process) {
        Write-Host "✅ 状态: 运行中" -ForegroundColor Green
        Write-Host "PID: $($process.Id)" -ForegroundColor Gray
        Write-Host "内存: $([math]::Round($process.WorkingSet64 / 1MB, 2)) MB" -ForegroundColor Gray
        Write-Host "启动时间: $($process.StartTime)" -ForegroundColor Gray
    } else {
        Write-Host "❌ 状态: 未运行" -ForegroundColor Red
    }
    
    Write-Host "`n日志文件:" -ForegroundColor Yellow
    Write-Host "  应用日志: $LogFile" -ForegroundColor Gray
    Write-Host "  调试日志: $DebugLog" -ForegroundColor Gray
    
    if (Test-Path $LogFile) {
        Write-Host "`n最近日志 (最后5行):" -ForegroundColor Yellow
        Write-Host "-------------------" -ForegroundColor Gray
        Get-Content $LogFile -Tail 5 | ForEach-Object { Write-Host $_ -ForegroundColor Gray }
    }
}

function Start-Plugin {
    Write-Host "`n🚀 启动 $PluginName..." -ForegroundColor Cyan
    
    # 检查是否已经在运行
    $existing = Get-Process -Name "node" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*cli.js*" }
    if ($existing) {
        Write-Host "⚠️  插件已在运行 (PID: $($existing.Id))" -ForegroundColor Yellow
        Write-Host "如需重启，请先运行: .\manage.ps1 -Action stop" -ForegroundColor Gray
        return
    }
    
    # 清空旧日志
    if (Test-Path $LogFile) { Remove-Item $LogFile -Force }
    if (Test-Path $DebugLog) { Remove-Item $DebugLog -Force }
    
    # 启动插件
    $scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
    $nodePath = Get-Command node -ErrorAction SilentlyContinue
    
    if (-not $nodePath) {
        Write-Host "❌ 错误: Node.js 未安装" -ForegroundColor Red
        return
    }
    
    Start-Process -FilePath "node" -ArgumentList "$scriptPath\bin\cli.js", "start" -RedirectStandardOutput $LogFile -RedirectStandardError $LogFile -WindowStyle Hidden
    
    # 等待启动
    Start-Sleep -Seconds 3
    
    $process = Get-Process -Name "node" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*cli.js*" }
    if ($process) {
        Write-Host "✅ 插件启动成功!" -ForegroundColor Green
        Write-Host "PID: $($process.Id)" -ForegroundColor Gray
        Write-Host "`n查看日志:" -ForegroundColor Yellow
        Write-Host "  Get-Content '$DebugLog' -Tail 20 -Wait" -ForegroundColor Gray
    } else {
        Write-Host "❌ 插件启动失败!" -ForegroundColor Red
        Write-Host "查看错误日志: $LogFile" -ForegroundColor Gray
    }
}

function Stop-Plugin {
    Write-Host "`n🛑 停止 $PluginName..." -ForegroundColor Cyan
    
    $processes = Get-Process -Name "node" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*cli.js*" }
    
    if ($processes) {
        $processes | ForEach-Object {
            Write-Host "结束进程 PID: $($_.Id)" -ForegroundColor Gray
            Stop-Process -Id $_.Id -Force
        }
        Write-Host "✅ 插件已停止" -ForegroundColor Green
    } else {
        Write-Host "⚠️  插件未在运行" -ForegroundColor Yellow
    }
}

function Deploy-Plugin {
    Write-Host "`n🚀 部署 $PluginName..." -ForegroundColor Cyan
    Write-Host "==============================" -ForegroundColor Cyan
    
    # 检查 Node.js
    Write-Host "`n📦 检查 Node.js..." -ForegroundColor Yellow
    $nodeVersion = node --version 2>$null
    if (-not $nodeVersion) {
        Write-Host "❌ 错误: Node.js 未安装" -ForegroundColor Red
        Write-Host "请先安装 Node.js 18+ 从 https://nodejs.org/" -ForegroundColor Gray
        return
    }
    Write-Host "✅ Node.js 版本: $nodeVersion" -ForegroundColor Green
    
    # 检查 npm
    Write-Host "`n📦 检查 npm..." -ForegroundColor Yellow
    $npmVersion = npm --version 2>$null
    Write-Host "✅ npm 版本: $npmVersion" -ForegroundColor Green
    
    # 安装依赖
    Write-Host "`n📦 安装依赖..." -ForegroundColor Yellow
    $scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
    Set-Location $scriptPath
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ 依赖安装失败" -ForegroundColor Red
        return
    }
    Write-Host "✅ 依赖安装完成" -ForegroundColor Green
    
    # 编译
    Write-Host "`n🔨 编译项目..." -ForegroundColor Yellow
    npm run build
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ 编译失败" -ForegroundColor Red
        return
    }
    Write-Host "✅ 编译完成" -ForegroundColor Green
    
    # 创建配置目录
    $configDir = "$env:USERPROFILE\.opencode"
    if (-not (Test-Path $configDir)) {
        New-Item -ItemType Directory -Path $configDir -Force | Out-Null
        Write-Host "✅ 创建配置目录: $configDir" -ForegroundColor Green
    }
    
    # 创建配置文件
    $configFile = "$configDir\config.yaml"
    if (-not (Test-Path $configFile)) {
        Write-Host "`n📝 创建默认配置文件..." -ForegroundColor Yellow
        @"
feishu:
  enabled: true
  appId: ""
  appSecret: ""
  allowFrom: []
  sessionTimeout: 3600
  maxMessageLength: 4000
"@ | Out-File -FilePath $configFile -Encoding UTF8
        Write-Host "✅ 配置文件已创建: $configFile" -ForegroundColor Green
        Write-Host "⚠️  请编辑配置文件，填写你的飞书 App ID 和 App Secret" -ForegroundColor Yellow
    } else {
        Write-Host "✅ 配置文件已存在" -ForegroundColor Green
    }
    
    Write-Host "`n🎉 部署完成！" -ForegroundColor Green
    Write-Host "`n使用说明:" -ForegroundColor Cyan
    Write-Host "  .\manage.ps1 -Action start   # 启动插件" -ForegroundColor Gray
    Write-Host "  .\manage.ps1 -Action stop    # 停止插件" -ForegroundColor Gray
    Write-Host "  .\manage.ps1 -Action status  # 查看状态" -ForegroundColor Gray
}

# 主逻辑
switch ($Action) {
    "start" { Start-Plugin }
    "stop" { Stop-Plugin }
    "restart" { Stop-Plugin; Start-Sleep -Seconds 2; Start-Plugin }
    "deploy" { Deploy-Plugin }
    default { Show-Status }
}

Write-Host "`n"
