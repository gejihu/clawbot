# OpenCode 飞书插件部署指南

## 系统要求

- **Linux/macOS**: Bash, Node.js 18+, OpenCode CLI
- **Windows**: PowerShell 5.1+ 或 cmd, Node.js 18+, OpenCode CLI

---

## Linux/macOS 部署

### 1. 解压插件包

```bash
tar -xzf opencode-feishu-plugin.tar.gz
cd opencode-feishu-plugin
```

### 2. 运行部署脚本

```bash
./deploy.sh
```

部署脚本会自动：
- 检查 Node.js 版本（需要 18+）
- 安装 npm 依赖
- 编译 TypeScript 项目
- 创建配置文件
- 安装快捷命令

### 3. 配置飞书应用

编辑配置文件 `~/.opencode/config.yaml`：

```yaml
feishu:
  enabled: true
  appId: "cli_xxxxx"              # 你的飞书 App ID
  appSecret: "xxxxx"              # 你的飞书 App Secret
  allowFrom: []                   # 允许的用户列表（空表示允许所有）
  sessionTimeout: 3600            # 会话超时时间（秒）
  maxMessageLength: 4000          # 最大消息长度
```

### 4. 启动插件

```bash
./start.sh
```

或者使用快捷命令（如果 deploy.sh 已运行）：

```bash
opencode-feishu
```

## 系统要求

- Node.js 18+
- OpenCode CLI 已安装
- 飞书开放平台账号

## 飞书应用配置

1. 登录 [飞书开放平台](https://open.feishu.cn/)
2. 创建企业自建应用
3. 启用机器人功能
4. 记录 App ID 和 App Secret
5. 配置事件订阅（如果有 Webhook 需求）
6. 发布应用到企业

## 命令说明

### 启动插件
```bash
./start.sh
```

### 停止插件
```bash
./stop.sh
```

### 查看状态
```bash
./status.sh
```

### 部署（首次运行）
```bash
./deploy.sh
```

## 日志文件

- 应用日志: `/tmp/feishu-plugin.log`
- 调试日志: `/tmp/opencode-feishu-debug.log`

查看实时日志：
```bash
tail -f /tmp/opencode-feishu-debug.log
```

---

## Windows 部署

### 方式一：PowerShell（推荐）

#### 1. 解压插件包
使用 7-Zip 或 Windows 资源管理器解压 `opencode-feishu-plugin.zip`

#### 2. 打开 PowerShell
右键点击开始菜单，选择 **Windows PowerShell** 或 **终端**

#### 3. 进入插件目录
```powershell
cd C:\path\to\opencode-feishu-plugin
```

#### 4. 运行部署脚本
```powershell
.\deploy.bat
```
或者使用 PowerShell 版本（功能更丰富）：
```powershell
.\manage.ps1 -Action deploy
```

#### 5. 管理插件

**使用 manage.ps1（推荐）：**
```powershell
.\manage.ps1 -Action start    # 启动
.\manage.ps1 -Action stop     # 停止
.\manage.ps1 -Action restart  # 重启
.\manage.ps1 -Action status   # 查看状态
```

**使用批处理脚本：**
```batch
start.bat   # 启动
stop.bat    # 停止
status.bat  # 查看状态
```

### 方式二：命令提示符 (cmd)

#### 1. 解压并进入目录
```cmd
cd C:\path\to\opencode-feishu-plugin
```

#### 2. 部署
```cmd
deploy.bat
```

#### 3. 启动
```cmd
start.bat
```

### Windows 日志文件

- 应用日志: `%TEMP%\feishu-plugin.log`
- 调试日志: `%TEMP%\opencode-feishu-debug.log`

在 PowerShell 中查看：
```powershell
Get-Content $env:TEMP\opencode-feishu-debug.log -Tail 20 -Wait
```

---

## 使用说明

### 基础对话

在飞书中向机器人发送消息，即可与 OpenCode AI 对话。

### 模型管理

- `!models` - 查看可用模型列表
- `!models refresh` - 刷新模型列表
- `!model <模型名>` - 切换到指定模型

例如：
- `!model opencode/minimax-m2.5-free`
- `!model opencode/kimi-k2.5-free`

### 功能特性

✅ 自动发现 OpenCode serve 端口
✅ 动态获取可用模型列表
✅ 支持模型切换
✅ 自动重连
✅ 消息确认反馈
✅ 多轮对话支持

## 常见问题

### Q: 插件启动失败，提示找不到 OpenCode
A: 确保已安装 OpenCode CLI，并且可以通过 `opencode` 命令访问

### Q: 消息发送成功但没有收到 AI 回复
A: 检查 OpenCode serve 是否正在运行：`opencode serve`

### Q: 飞书收不到消息
A: 检查飞书应用的 App ID 和 App Secret 是否正确配置

### Q: 如何更新模型列表
A: 发送 `!models refresh` 命令刷新模型列表

## 文件说明

```
opencode-feishu-plugin/
├── bin/                  # CLI 入口
├── dist/                 # 编译后的代码
├── src/                  # 源代码
├── node_modules/         # 依赖包
├── deploy.sh            # 部署脚本
├── start.sh             # 启动脚本
├── stop.sh              # 停止脚本
├── status.sh            # 状态检查脚本
├── package.json         # 项目配置
├── README.md            # 说明文档
└── DEPLOY.md            # 本文件
```

## 技术支持

- OpenCode: https://github.com/anomalyco/opencode
- 飞书开放平台: https://open.feishu.cn/

## 许可证

MIT
