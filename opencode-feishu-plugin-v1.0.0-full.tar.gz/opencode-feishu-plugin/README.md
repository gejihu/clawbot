# OpenCode Feishu Plugin

为 OpenCode AI 编程助手添加飞书（Feishu/Lark）对话能力。

## 功能特性

- 通过飞书与 OpenCode 对话
- 支持单聊和群聊
- 消息历史和会话管理
- 自动重连机制
- 用户白名单控制

## 安装

```bash
# 克隆项目
git clone https://github.com/yourusername/opencode-feishu-plugin.git
cd opencode-feishu-plugin

# 安装依赖
npm install

# 构建
npm run build
```

## 配置

1. 创建飞书应用：
   - 访问[飞书开放平台](https://open.feishu.cn/app)
   - 创建新应用并启用 Bot 能力
   - 添加权限：`im:message`
   - 添加事件：`im.message.receive_v1`（长连接模式）
   - 获取 App ID 和 App Secret

2. 初始化配置：

```bash
./bin/cli.js init
```

3. 编辑配置文件 `~/.opencode/config.yaml`：

```yaml
feishu:
  enabled: true
  appId: "your-app-id"
  appSecret: "your-app-secret"
  allowFrom: []  # 空数组表示允许所有用户
  sessionTimeout: 3600
  maxMessageLength: 4000
```

## 使用

### 启动插件

```bash
./bin/cli.js start
```

### 检查状态

```bash
./bin/cli.js status
```

### 测试连接

```bash
./bin/cli.js test
```

## 命令

| 命令 | 描述 |
|------|------|
| `start` | 启动飞书插件 |
| `stop` | 停止插件 |
| `status` | 检查插件状态 |
| `init` | 初始化配置文件 |
| `test` | 测试飞书连接 |

## 目录结构

```
opencode-feishu-plugin/
├── bin/
│   └── cli.js           # CLI 入口
├── src/
│   ├── cli/
│   │   └── index.ts     # CLI 命令定义
│   ├── config/
│   │   ├── schema.ts    # 配置模式
│   │   └── loader.ts    # 配置加载器
│   ├── feishu/
│   │   ├── client.ts    # WebSocket 客户端
│   │   ├── handler.ts   # 消息处理器
│   │   └── types.ts     # 类型定义
│   ├── channel/
│   │   └── formatter.ts # 消息格式化
│   ├── session/
│   │   └── manager.ts   # 会话管理
│   ├── opencode/
│   │   └── agent.ts     # OpenCode 集成
│   ├── types/
│   │   └── index.ts     # 共享类型
│   ├── utils/
│   │   └── logger.ts    # 日志工具
│   └── index.ts         # 插件主入口
├── package.json
├── tsconfig.json
└── README.md
```

## 架构设计

```
┌─────────────────────────────────────────────┐
│              OpenCode Feishu Plugin          │
├─────────────────────────────────────────────┤
│                                              │
│  ┌─────────────┐    ┌─────────────────────┐  │
│  │  Feishu     │───>│  Message Handler    │  │
│  │  WebSocket  │    │                     │  │
│  │  Client     │    │  - 消息验证          │  │
│  └─────────────┘    │  - 用户白名单        │  │
│                     │  - 消息路由          │  │
│                     └─────────┬───────────┘  │
│                               │              │
│                               ▼              │
│                     ┌─────────────────────┐  │
│                     │  Session Manager    │  │
│                     │                     │  │
│                     │  - 会话创建/获取     │  │
│                     │  - 消息历史          │  │
│                     │  - 过期清理          │  │
│                     └─────────┬───────────┘  │
│                               │              │
│                               ▼              │
│                     ┌─────────────────────┐  │
│                     │   OpenCode Agent    │  │
│                     │                     │  │
│                     │  - CLI 集成         │  │
│                     │  - 响应处理          │  │
│                     └─────────┬───────────┘  │
│                               │              │
│                               ▼              │
│                     ┌─────────────────────┐  │
│                     │  Message Formatter  │  │
│                     │                     │  │
│                     │  - 格式转换          │  │
│                     │  - 长度截断          │  │
│                     └─────────┬───────────┘  │
│                               │              │
│                               ▼              │
│                     ┌─────────────────────┐  │
│                     │  Feishu Client      │  │
│                     │  (WebSocket)        │  │
│                     │                     │  │
│                     │  - 发送消息          │  │
│                     │  - 心跳检测          │  │
│                     └─────────────────────┘  │
│                                              │
└─────────────────────────────────────────────┘
```

## 与 nanobot 的对比

| 特性 | nanobot | opencode-feishu-plugin |
|------|---------|------------------------|
| 代码行数 | ~3,500 | ~1,200 |
| 技术栈 | Python | TypeScript |
| 消息接收 | WebSocket 长连接 | WebSocket 长连接 |
| 会话管理 | 内置 | 独立模块 |
| 配置方式 | JSON 文件 | YAML 文件 |
| OpenCode 集成 | 不适用 | CLI 子进程 |

## 注意事项

1. 确保 OpenCode 已安装并在 PATH 中
2. 飞书应用需要正确配置事件订阅
3. 建议使用用户白名单限制访问
4. 定期检查日志排查问题

## License

MIT
