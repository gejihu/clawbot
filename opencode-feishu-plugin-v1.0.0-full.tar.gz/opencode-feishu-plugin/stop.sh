#!/bin/bash

# OpenCode 飞书插件停止脚本

echo "🛑 停止 OpenCode 飞书插件..."

# 查找并杀死进程
PID=$(pgrep -f "node bin/cli.js start")

if [ -n "$PID" ]; then
    echo "找到进程 PID: $PID"
    kill $PID
    sleep 2
    
    # 检查是否还在运行
    if ps -p $PID > /dev/null 2>&1; then
        echo "强制停止..."
        kill -9 $PID
    fi
    
    echo "✅ 插件已停止"
else
    echo "⚠️ 插件未在运行"
fi
